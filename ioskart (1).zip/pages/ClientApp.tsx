import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useNavigate, useParams, useLocation, useSearchParams } from 'react-router-dom';
import { Home, Search, ShoppingBag, User, LogOut, ChevronLeft, MapPin, CreditCard, Send, Plus, Minus, CheckCircle, Smartphone, Truck, RefreshCcw, Loader2, Info, Banknote, Shield, Grid, Trash, Clock, Package, AlertCircle } from 'lucide-react';
import { useApp } from '../store';
import { Button, Input, Modal, Badge, ConfirmModal } from '../components/Shared';
import { Product, Category, Review, Order, Address, UserProfile, BankDetails } from '../types';
import { collection, query, where, getDocs, getDoc, doc, setDoc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db } from '../firebase';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, sendPasswordResetEmail, signOut } from 'firebase/auth';
import { getChatResponse } from '../geminiService';
import { Edit } from 'lucide-react';

// --- Shared Layout Components ---

const Header: React.FC<{ showBack?: boolean, title?: string, hideCart?: boolean }> = ({ showBack, title, hideCart }) => {
  const { cart, settings } = useApp();
  const navigate = useNavigate();
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if(searchTerm.trim()) navigate(`/search?q=${searchTerm}`);
    setIsSearchOpen(false);
  };

  const goBack = () => {
    if (window.history.length > 2) {
        navigate(-1);
    } else {
        navigate('/');
    }
  };

  return (
    <>
    <header className="fixed top-0 left-0 right-0 z-40 bg-white/85 backdrop-blur-xl border-b border-gray-100 transition-all duration-300">
      <div className="max-w-md mx-auto px-4 h-14 flex items-center justify-between">
        <div className="flex items-center gap-2">
            {showBack ? (
            <button onClick={goBack} className="p-2 -ml-2 rounded-full hover:bg-gray-100 active:bg-gray-200 transition-colors text-blue-600">
                <ChevronLeft size={26} />
            </button>
            ) : null}
             
             {/* Logo / Title Left Aligned */}
             <div className="flex items-center gap-2">
                 {title ? (
                     <h1 className="font-bold text-base text-gray-900 line-clamp-1">{title}</h1>
                 ) : (
                    <Link to="/" className="font-bold text-xl tracking-tight text-blue-600 flex items-center gap-2">
                        {settings?.logoUrl ? <img src={settings.logoUrl} className="w-8 h-8 rounded-md object-cover" alt="logo"/> : null}
                        {settings?.siteName || 'IosKart'}
                    </Link>
                 )}
             </div>
        </div>
        
        <div className="flex items-center gap-1">
          {!title && (
              <button onClick={() => setIsSearchOpen(!isSearchOpen)} className="p-2 text-blue-600">
                  <Search className="w-6 h-6" />
              </button>
          )}
          
          {!hideCart && (
            <Link to="/cart" className="relative p-2 text-blue-600">
                <ShoppingBag className="w-6 h-6" />
                {cart.length > 0 && (
                <span className="absolute top-1 right-0 bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full shadow-sm animate-pulse">
                    {cart.length}
                </span>
                )}
            </Link>
          )}
          {hideCart && <div className="w-10"></div>} 
        </div>
      </div>
      
      {isSearchOpen && (
        <form onSubmit={handleSearch} className="px-4 pb-3 animate-[fade-in_0.2s]">
          <Input 
            autoFocus 
            placeholder="Search products..." 
            value={searchTerm} 
            onChange={e => setSearchTerm(e.target.value)} 
          />
        </form>
      )}
    </header>
    </>
  );
};

const TabBar = () => {
  const location = useLocation();
  const isActive = (path: string) => location.pathname === path ? 'text-blue-600' : 'text-gray-400';
  
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-xl border-t border-gray-200 pb-safe z-40 transition-all duration-300">
      <div className="max-w-md mx-auto flex justify-around items-center h-16">
        <Link to="/" className={`flex flex-col items-center gap-1 transition-colors ${isActive('/')}`}>
          <Home size={24} strokeWidth={isActive('/') ? 2.5 : 2} />
          <span className="text-[10px] font-medium">Home</span>
        </Link>
        <Link to="/categories" className={`flex flex-col items-center gap-1 transition-colors ${isActive('/categories')}`}>
          <Grid size={24} strokeWidth={isActive('/categories') ? 2.5 : 2} />
          <span className="text-[10px] font-medium">Categories</span>
        </Link>
        <Link to="/orders" className={`flex flex-col items-center gap-1 transition-colors ${isActive('/orders')}`}>
          <Truck size={24} strokeWidth={isActive('/orders') ? 2.5 : 2} />
          <span className="text-[10px] font-medium">Orders</span>
        </Link>
        <Link to="/profile" className={`flex flex-col items-center gap-1 transition-colors ${isActive('/profile')}`}>
          <User size={24} strokeWidth={isActive('/profile') ? 2.5 : 2} />
          <span className="text-[10px] font-medium">Profile</span>
        </Link>
      </div>
    </nav>
  );
};

interface PageLayoutProps {
    children: React.ReactNode;
    showBack?: boolean;
    title?: string;
    showTabs?: boolean;
    hideCart?: boolean;
    fullWidth?: boolean; 
}

const PageLayout: React.FC<PageLayoutProps> = ({ children, showBack, title, showTabs = true, hideCart, fullWidth }) => {
    return (
        <div className="bg-gray-50 min-h-screen font-sans selection:bg-blue-100">
            <Header showBack={showBack} title={title} hideCart={hideCart} />
            <main className={`${fullWidth ? 'pt-0' : 'pt-16'} ${showTabs ? 'pb-24' : 'pb-8'} min-h-screen animate-[fade-in_0.3s_ease-out]`}>
                {children}
            </main>
            {showTabs && <TabBar />}
        </div>
    );
};

const ProductCard: React.FC<{ product: Product }> = ({ product }) => {
  if (!product || !product.images || product.images.length === 0) return null; // Safe check
  const discount = product.mrp > 0 ? Math.round(((product.mrp - product.price) / product.mrp) * 100) : 0;
  return (
    <Link to={`/product/${product.id}`} className="bg-white rounded-2xl p-3 shadow-sm border border-gray-100 flex flex-col gap-2 hover:shadow-md transition-all active:scale-95 duration-200">
      <div className="aspect-square rounded-xl bg-gray-50 overflow-hidden relative">
        <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover" />
        {discount > 0 && <span className="absolute top-2 left-2 bg-green-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-sm">-{discount}%</span>}
        {product.isTrusted && <span className="absolute bottom-2 right-2 bg-blue-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded shadow-sm">Trusted</span>}
      </div>
      <div className="flex-1 flex flex-col justify-end">
        <h3 className="font-medium text-sm text-gray-900 line-clamp-2 leading-snug min-h-[2.5em]">{product.name}</h3>
        <div className="flex items-baseline gap-2 mt-1">
          <span className="font-bold text-base text-gray-900">₹{product.price}</span>
          <span className="text-xs text-gray-400 line-through">₹{product.mrp}</span>
        </div>
        {product.freeDelivery && <span className="text-[10px] text-green-600 font-medium bg-green-50 px-1 rounded w-fit mt-1">Free Delivery</span>}
      </div>
    </Link>
  );
};

// --- Pages ---

const InfoPage: React.FC<{ title: string, contentKey: 'privacyPolicy' | 'termsConditions' | 'refundPolicy' }> = ({ title, contentKey }) => {
    const { settings } = useApp();
    const content = settings?.[contentKey] || "No content available.";
    
    return (
        <PageLayout title={title} showBack showTabs={false}>
            <div className="p-6">
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                     <p className="whitespace-pre-line text-sm text-gray-700 leading-relaxed">{content}</p>
                </div>
            </div>
        </PageLayout>
    );
};

const CategoriesPage = () => {
    const [categories, setCategories] = useState<Category[]>([]);
    const navigate = useNavigate();

    useEffect(() => {
        getDocs(collection(db, 'categories')).then(s => setCategories(s.docs.map(d => ({id:d.id, ...d.data()} as Category))));
    }, []);

    return (
        <PageLayout title="All Categories" showTabs={true}>
            <div className="grid grid-cols-3 gap-4 p-4">
                {categories.map(c => (
                    <div key={c.id} onClick={()=>navigate(`/search?cat=${c.id}`)} className="flex flex-col items-center gap-2 group cursor-pointer">
                        <div className="w-20 h-20 rounded-full bg-white border border-gray-100 shadow-sm overflow-hidden group-hover:scale-105 transition-transform duration-300">
                            <img src={c.image} className="w-full h-full object-cover" alt={c.name}/>
                        </div>
                        <span className="text-xs text-center font-medium text-gray-700 group-hover:text-blue-600 transition-colors leading-tight">{c.name}</span>
                    </div>
                ))}
            </div>
        </PageLayout>
    );
};

const CategoryResultsPage = () => {
    const [searchParams] = useSearchParams();
    const catId = searchParams.get('cat');
    const searchTerm = searchParams.get('q');
    const [products, setProducts] = useState<Product[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetch = async () => {
            setLoading(true);
            try {
                let q;
                const ref = collection(db, 'products');
                if (catId) {
                    q = query(ref, where('categoryId', '==', catId));
                } else {
                    q = query(ref);
                }
                const snap = await getDocs(q);
                let res = snap.docs.map(d => ({id:d.id, ...d.data()} as Product));
                if (searchTerm) {
                    res = res.filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()));
                }
                setProducts(res);
            } catch(e) { console.error(e) } 
            finally { setLoading(false); }
        };
        fetch();
    }, [catId, searchTerm]);

    return (
        <PageLayout title={catId ? "Category Items" : "Search Results"} showBack showTabs={true}>
            {loading ? <div className="flex justify-center p-10"><Loader2 className="animate-spin"/></div> : (
                <div className="grid grid-cols-2 gap-4 p-4">
                    {products.map(p => <ProductCard key={p.id} product={p} />)}
                    {products.length === 0 && <p className="col-span-2 text-center text-gray-500 py-10">No products found.</p>}
                </div>
            )}
        </PageLayout>
    );
};

const HomePage = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const { settings } = useApp();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const catSnap = await getDocs(collection(db, 'categories'));
        setCategories(catSnap.docs.map(d => ({ id: d.id, ...d.data() } as Category)));
        
        const prodSnap = await getDocs(collection(db, 'products'));
        setProducts(prodSnap.docs.map(d => ({ id: d.id, ...d.data() } as Product)));
      } catch (e) {
        console.error("Error fetching data", e);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) return <div className="h-screen flex items-center justify-center"><Loader2 className="animate-spin text-blue-600 w-8 h-8"/></div>;

  return (
    <PageLayout showTabs={true}>
      <div className="px-4 pt-2">
        <div className="w-full aspect-[21/9] bg-gradient-to-br from-blue-600 to-indigo-700 rounded-3xl mb-8 flex flex-col items-center justify-center shadow-xl shadow-blue-200/50 p-6 text-center">
           <h2 className="text-white text-xl font-bold tracking-tight mb-2">Welcome to {settings?.siteName}</h2>
           <p className="text-blue-100 text-xs font-medium bg-white/10 px-3 py-1 rounded-full backdrop-blur">Premium Shopping Experience</p>
        </div>

        {categories.length > 0 && (
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-lg text-gray-900">Categories</h3>
            <Link to="/categories" className="text-xs font-medium text-blue-600">See all</Link>
          </div>
          <div className="flex gap-5 overflow-x-auto no-scrollbar pb-2 px-1">
            {categories.map(cat => (
              <Link to={`/search?cat=${cat.id}`} key={cat.id} className="flex-shrink-0 flex flex-col items-center gap-2 group w-18">
                <div className="w-16 h-16 rounded-full bg-white border border-gray-100 shadow-sm overflow-hidden group-hover:scale-105 transition-transform duration-300">
                  <img src={cat.image} className="w-full h-full object-cover" alt={cat.name}/>
                </div>
                <span className="text-xs text-center font-medium text-gray-600 group-hover:text-blue-600 transition-colors leading-tight">{cat.name}</span>
              </Link>
            ))}
          </div>
        </div>
        )}

        <div>
          <h3 className="font-bold text-lg mb-4 text-gray-900">Just For You</h3>
          {products.length === 0 ? (
            <div className="text-center py-10 text-gray-400 text-sm">No products found.</div>
          ) : (
            <div className="grid grid-cols-2 gap-4 pb-4">
                {products.map(p => <ProductCard key={p.id} product={p} />)}
            </div>
          )}
        </div>
      </div>
    </PageLayout>
  );
};

const ProductPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart, addToast } = useApp();
  const [product, setProduct] = useState<Product | null>(null);
  const [related, setRelated] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedSize, setSelectedSize] = useState<string>('');

  useEffect(() => {
    if (!id) return;
    const fetchP = async () => {
      try {
        const docRef = doc(db, 'products', id);
        const snap = await getDoc(docRef);
        if (snap.exists()) {
            const p = { id: snap.id, ...snap.data() } as Product;
            setProduct(p);
            if(p.sizes && p.sizes.length > 0) setSelectedSize(p.sizes[0]);

            if(p.categoryId) {
                const q = query(collection(db, 'products'), where('categoryId', '==', p.categoryId));
                const relSnap = await getDocs(q);
                setRelated(relSnap.docs.map(d => ({id: d.id, ...d.data()} as Product)).filter(x => x.id !== p.id));
            } else {
                 const q = query(collection(db, 'products'));
                 const relSnap = await getDocs(q);
                 setRelated(relSnap.docs.map(d => ({id: d.id, ...d.data()} as Product)).filter(x => x.id !== p.id).slice(0, 5));
            }
        }
      } catch (e) {
          console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchP();
    window.scrollTo(0, 0);
  }, [id]);

  const handleAddToCart = () => {
      if(product?.sizes && product.sizes.length > 0 && !selectedSize) {
          addToast("Please select a size", "error");
          return;
      }
      if(product) {
          addToCart({...product, quantity: 1, selectedSize});
      }
  };

  if (loading) return <div className="h-screen flex items-center justify-center"><Loader2 className="animate-spin text-blue-600 w-8 h-8"/></div>;
  if (!product) return <div className="h-screen flex flex-col items-center justify-center gap-4 text-gray-500">Product not found <Button onClick={()=>navigate(-1)}>Go Back</Button></div>;

  const deliveryDate = new Date();
  deliveryDate.setDate(deliveryDate.getDate() + 9);
  const discount = product.mrp > 0 ? Math.round(((product.mrp - product.price)/product.mrp)*100) : 0;

  return (
    <PageLayout showTabs={false} showBack={true} fullWidth={true}>
      <div className="relative w-full aspect-square bg-white">
        <div className="pt-14 h-full"> 
             <img src={product.images && product.images.length > 0 ? product.images[0] : ''} className="w-full h-full object-cover" alt={product.name}/>
        </div>
      </div>
      
      <div className="p-6 -mt-8 bg-white rounded-t-[2rem] relative z-10 shadow-[0_-10px_40px_rgba(0,0,0,0.05)] pb-32">
        <div className="flex justify-between items-start mb-2">
          <h1 className="text-xl font-bold text-gray-900 leading-snug flex-1 mr-2">{product.name}</h1>
          {product.isTrusted && <Badge color="bg-blue-50 text-blue-600 border border-blue-100">Trusted</Badge>}
        </div>
        
        <div className="flex items-center gap-3 mb-6">
          <span className="text-3xl font-bold text-gray-900">₹{product.price}</span>
          <div className="flex flex-col items-start leading-none">
             <span className="text-sm text-gray-400 line-through">₹{product.mrp}</span>
             <span className="text-sm font-bold text-green-600">{discount}% OFF</span>
          </div>
        </div>

        {product.sizes && product.sizes.length > 0 && (
            <div className="mb-6">
                <h3 className="font-bold text-sm text-gray-900 mb-3">Select Size</h3>
                <div className="flex flex-wrap gap-2">
                    {product.sizes.map(size => (
                        <button 
                            key={size} 
                            onClick={()=>setSelectedSize(size)}
                            className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold border transition-all ${selectedSize === size ? 'bg-black text-white border-black' : 'bg-white text-gray-900 border-gray-200 hover:border-gray-400'}`}
                        >
                            {size}
                        </button>
                    ))}
                </div>
            </div>
        )}

        <div className="grid grid-cols-3 gap-3 mb-8">
            {[
                {icon: Truck, text: `By ${deliveryDate.getDate()} ${deliveryDate.toLocaleString('default', { month: 'short' })}`},
                {icon: RefreshCcw, text: "8 Days Return"},
                {icon: CreditCard, text: "3 Day Refund"}
            ].map((item, idx) => (
                <div key={idx} className="bg-gray-50 rounded-2xl p-3 flex flex-col items-center justify-center gap-2 border border-gray-100">
                    <item.icon className="w-6 h-6 text-gray-700"/>
                    <p className="text-[10px] font-medium text-gray-500 text-center leading-tight">{item.text}</p>
                </div>
            ))}
        </div>

        <div className="mb-8">
            <h3 className="font-bold text-base text-gray-900 mb-3">Description</h3>
            <p className="text-gray-600 text-sm leading-relaxed whitespace-pre-line">{product.description}</p>
        </div>

        <div className="mb-8">
            <h3 className="font-bold text-base text-gray-900 mb-4">Reviews ({product.reviews?.length || 0})</h3>
            <div className="space-y-4">
                {product.reviews?.map((r, i) => (
                    <div key={i} className="flex gap-4 border-b border-gray-100 pb-4 last:border-0">
                        <img src={r.userImage} className="w-10 h-10 rounded-full bg-gray-200 object-cover" alt="u"/>
                        <div>
                            <p className="text-sm font-bold text-gray-900">{r.userName}</p>
                            <div className="flex text-yellow-400 text-xs my-1">{"★".repeat(r.rating)}</div>
                            <p className="text-sm text-gray-600 leading-relaxed">{r.text}</p>
                        </div>
                    </div>
                ))}
                {!product.reviews?.length && <p className="text-sm text-gray-400 italic">No reviews yet.</p>}
            </div>
        </div>

        {related.length > 0 && (
          <div className="mb-4">
             <h3 className="font-bold text-base text-gray-900 mb-4">You might also like</h3>
             <div className="flex gap-4 overflow-x-auto no-scrollbar pb-4">
                {related.map(p => (
                   <div key={p.id} onClick={()=>navigate(`/product/${p.id}`)} className="w-36 flex-shrink-0 group cursor-pointer">
                      <div className="w-36 h-36 rounded-2xl bg-gray-100 mb-2 overflow-hidden">
                        <img src={p.images[0]} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" alt={p.name}/>
                      </div>
                      <p className="text-xs font-medium truncate text-gray-700">{p.name}</p>
                      <p className="text-sm font-bold text-gray-900">₹{p.price}</p>
                   </div>
                ))}
             </div>
          </div>
        )}
      </div>

      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white/90 backdrop-blur-xl border-t border-gray-100 flex gap-3 z-50 pb-safe animate-[slide-in-bottom_0.3s_ease-out]">
         <Button variant="secondary" className="flex-1 rounded-xl" onClick={handleAddToCart}>
            Add to Cart
         </Button>
         <Button className="flex-1 rounded-xl" onClick={() => { handleAddToCart(); navigate('/cart'); }}>
            Buy Now
         </Button>
      </div>
    </PageLayout>
  );
};

const CartPage = () => {
  const { cart, updateCartQuantity } = useApp();
  const navigate = useNavigate();
  const total = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  const discount = cart.reduce((acc, item) => acc + ((item.mrp - item.price) * item.quantity), 0);

  if (cart.length === 0) return (
    <PageLayout showTabs={true} title="My Cart" showBack={true}>
        <div className="h-[70vh] flex flex-col items-center justify-center p-8 text-center">
            <div className="w-24 h-24 bg-blue-50 rounded-full flex items-center justify-center mb-6">
                <ShoppingBag className="w-10 h-10 text-blue-500"/>
            </div>
            <h2 className="text-xl font-bold text-gray-900 mb-2">Your bag is empty</h2>
            <p className="text-gray-500 text-sm mb-8 max-w-xs mx-auto">Looks like you haven't added anything to your cart yet.</p>
            <Button onClick={() => navigate('/')} className="w-48">Start Shopping</Button>
        </div>
    </PageLayout>
  );

  return (
    <PageLayout showTabs={false} showBack={true} title="My Cart">
      <div className="p-4 space-y-4">
        {cart.map(item => (
          <div key={item.cartItemId} className="bg-white rounded-2xl p-3 flex gap-4 shadow-sm border border-gray-50">
            <img src={item.images[0]} className="w-24 h-24 rounded-xl object-cover bg-gray-50" alt={item.name} />
            <div className="flex-1 flex flex-col justify-between py-1">
              <div>
                <h3 className="font-medium text-sm text-gray-900 line-clamp-2">{item.name}</h3>
                <div className="flex gap-2 mt-1">
                    <p className="text-xs text-green-600 font-medium">In Stock</p>
                    {item.selectedSize && <p className="text-xs text-gray-500 bg-gray-100 px-1 rounded">Size: {item.selectedSize}</p>}
                </div>
              </div>
              <div className="flex justify-between items-end">
                 <div className="font-bold text-lg">₹{item.price * item.quantity}</div>
                 <div className="flex items-center gap-3 bg-gray-50 rounded-lg p-1 border border-gray-100">
                    <button onClick={() => updateCartQuantity(item.cartItemId, item.quantity - 1)} className="p-1 hover:bg-white rounded-md transition-colors"><Minus size={14}/></button>
                    <span className="text-xs font-bold w-4 text-center">{item.quantity}</span>
                    <button onClick={() => updateCartQuantity(item.cartItemId, item.quantity + 1)} className="p-1 hover:bg-white rounded-md transition-colors"><Plus size={14}/></button>
                 </div>
              </div>
            </div>
          </div>
        ))}
        
        <div className="bg-white rounded-2xl p-5 shadow-sm mt-6">
          <h3 className="font-bold text-sm mb-4 text-gray-900">Price Details</h3>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between text-gray-600"><span>Price ({cart.length} items)</span><span>₹{total + discount}</span></div>
            <div className="flex justify-between text-green-600"><span>Discount</span><span>- ₹{discount}</span></div>
            <div className="flex justify-between text-green-600"><span>Delivery Charges</span><span>Free</span></div>
            <div className="border-t border-dashed border-gray-200 pt-3 mt-3 flex justify-between font-bold text-lg text-gray-900">
              <span>Total Amount</span><span>₹{total}</span>
            </div>
          </div>
        </div>
      </div>
      
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white/90 backdrop-blur-xl border-t border-gray-100 z-50 pb-safe">
        <Button className="w-full h-12 text-base shadow-lg shadow-blue-200" onClick={() => navigate('/checkout')}>Checkout • ₹{total}</Button>
      </div>
    </PageLayout>
  );
};

const AddressesPage = () => {
    const { user, profile, addToast, refreshProfile } = useApp();
    const navigate = useNavigate();
    const [editing, setEditing] = useState<Partial<Address> | null>(null);
    const [showModal, setShowModal] = useState(false);
    
    // Deletion State
    const [deleteId, setDeleteId] = useState<string | null>(null);
    const [isDeleting, setIsDeleting] = useState(false);

    if(!user) return <AuthPage />;

    const handleSave = async () => {
        if(!editing || !editing.fullName || !editing.mobile || !editing.street || !editing.zipCode) {
            return addToast("Please fill required fields", "error");
        }
        
        const addr: Address = {
            id: editing.id || Date.now().toString(),
            fullName: editing.fullName,
            mobile: editing.mobile,
            street: editing.street,
            landmark: editing.landmark || '',
            city: editing.city || '',
            state: editing.state || '',
            zipCode: editing.zipCode
        };

        let newAddresses = [...(profile?.addresses || [])];
        if (editing.id) {
            newAddresses = newAddresses.map(a => a.id === editing.id ? addr : a);
        } else {
            newAddresses.push(addr);
        }

        await updateDoc(doc(db, 'users', user.uid), { addresses: newAddresses });
        await refreshProfile();
        setShowModal(false);
        setEditing(null);
        addToast("Address Saved", "success");
    };

    const confirmDelete = async () => {
        if(!deleteId || !user) return;
        setIsDeleting(true);
        try {
            const newAddresses = profile?.addresses?.filter(a => a.id !== deleteId) || [];
            await updateDoc(doc(db, 'users', user.uid), { addresses: newAddresses });
            await refreshProfile();
            addToast("Address Deleted", "success");
        } catch (error) {
            console.error(error);
            addToast("Failed to delete address", "error");
        } finally {
            setIsDeleting(false);
            setDeleteId(null);
        }
    };

    return (
        <PageLayout title="My Addresses" showBack showTabs={false}>
            <div className="p-4 space-y-4">
                <Button variant="outline" className="w-full border-dashed border-2 py-4" onClick={() => { setEditing({}); setShowModal(true); }}>
                    <Plus className="w-5 h-5 mr-2" /> Add New Address
                </Button>

                {profile?.addresses?.map(addr => (
                    <div key={addr.id} className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm relative">
                        <div className="pr-10">
                            <h4 className="font-bold text-gray-900">{addr.fullName}</h4>
                            <p className="text-sm text-gray-500 mb-1">{addr.street}, {addr.landmark ? addr.landmark + ', ' : ''}{addr.city}</p>
                            <p className="text-sm text-gray-500">{addr.state} - {addr.zipCode}</p>
                            <p className="text-sm font-medium mt-2">Mobile: {addr.mobile}</p>
                        </div>
                        <div className="absolute top-4 right-4 flex flex-col gap-2">
                             <button onClick={() => { setEditing(addr); setShowModal(true); }} className="p-2 text-blue-600 bg-blue-50 rounded-lg"><Edit size={16}/></button>
                             <button onClick={() => setDeleteId(addr.id)} className="p-2 text-red-600 bg-red-50 rounded-lg"><Trash size={16}/></button>
                        </div>
                    </div>
                ))}
                {!profile?.addresses?.length && <p className="text-center text-gray-400 mt-10">No addresses found.</p>}
            </div>

            <Modal isOpen={showModal} onClose={() => setShowModal(false)} title={editing?.id ? "Edit Address" : "Add Address"}>
                 <div className="space-y-3">
                    <Input label="Full Name" value={editing?.fullName || ''} onChange={e => setEditing({...editing, fullName: e.target.value})} />
                    <Input label="Mobile Number" value={editing?.mobile || ''} onChange={e => setEditing({...editing, mobile: e.target.value})} />
                    <Input label="Street / Village / Area" value={editing?.street || ''} onChange={e => setEditing({...editing, street: e.target.value})} />
                    <Input label="Landmark (Optional)" value={editing?.landmark || ''} onChange={e => setEditing({...editing, landmark: e.target.value})} />
                    <div className="flex gap-2">
                         <Input label="City / District" value={editing?.city || ''} onChange={e => setEditing({...editing, city: e.target.value})} />
                         <Input label="State" value={editing?.state || ''} onChange={e => setEditing({...editing, state: e.target.value})} />
                    </div>
                    <Input label="Pincode" value={editing?.zipCode || ''} onChange={e => setEditing({...editing, zipCode: e.target.value})} />
                    <Button className="w-full mt-2" onClick={handleSave}>Save Address</Button>
                 </div>
            </Modal>
            
            <ConfirmModal 
                isOpen={!!deleteId} 
                onClose={() => setDeleteId(null)} 
                onConfirm={confirmDelete}
                title="Delete Address"
                message="Are you sure you want to delete this address? This action cannot be undone."
                isLoading={isDeleting}
            />
        </PageLayout>
    );
};

const CheckoutPage = () => {
  const { cart, user, profile, settings, addToast, clearCart, refreshProfile } = useApp();
  const navigate = useNavigate();
  const [selectedAddress, setSelectedAddress] = useState<Address | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<'COD' | 'Online'>('Online');
  const [coupon, setCoupon] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<any>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showAddAddress, setShowAddAddress] = useState(false);
  const [newAddr, setNewAddr] = useState<Partial<Address>>({});

  useEffect(() => {
      if (profile?.addresses && profile.addresses.length > 0 && !selectedAddress) {
          setSelectedAddress(profile.addresses[0]);
      }
  }, [profile, selectedAddress]);

  const subtotal = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  const totalMrp = cart.reduce((acc, item) => acc + (item.mrp * item.quantity), 0);
  const productDiscount = totalMrp - subtotal;
  
  const couponDiscount = appliedCoupon ? (appliedCoupon.discountType === 'FLAT' ? appliedCoupon.value : (subtotal * appliedCoupon.value / 100)) : 0;
  const finalTotal = subtotal - couponDiscount;

  const handleApplyCoupon = async () => {
     if(!coupon) return;
     const q = query(collection(db, 'coupons'), where('code', '==', coupon.toUpperCase()), where('active', '==', true));
     const snap = await getDocs(q);
     if(!snap.empty) {
        setAppliedCoupon(snap.docs[0].data());
        addToast("Coupon applied!", "success");
     } else {
        addToast("Invalid coupon code", "error");
        setAppliedCoupon(null);
     }
  };

  const handleSaveAddress = async () => {
     if (!user) return;
     const addr: Address = {
        id: Date.now().toString(),
        fullName: newAddr.fullName || '',
        street: newAddr.street || '',
        city: newAddr.city || '',
        state: newAddr.state || '',
        zipCode: newAddr.zipCode || '',
        mobile: newAddr.mobile || '',
        landmark: newAddr.landmark || ''
     } as Address;
     
     try {
         const newAddresses = [...(profile?.addresses || []), addr];
         await updateDoc(doc(db, 'users', user.uid), { addresses: newAddresses });
         await refreshProfile(); // Refresh profile to show new address
         setSelectedAddress(addr);
         setShowAddAddress(false);
         setNewAddr({});
         addToast("Address saved", "success");
     } catch(e) {
         console.error(e);
         addToast("Failed to save address", "error");
     }
  };

  const handlePlaceOrder = async () => {
    if(!user) {
       addToast("Please login to place order", "error");
       navigate('/login');
       return;
    }
    if(!selectedAddress) {
       addToast("Please select an address", "error");
       return;
    }

    setIsProcessing(true);

    if (paymentMethod === 'Online') {
      const upiLink = `upi://pay?pa=${settings?.adminUpiId}&pn=${settings?.siteName}&am=${finalTotal}&cu=INR`;
      window.location.href = upiLink;
      setTimeout(() => confirmOrder(), 5000); 
    } else {
      confirmOrder();
    }
  };

  const confirmOrder = async () => {
    const order: Order = {
      id: `ORD-${Date.now()}`,
      uid: user!.uid,
      items: cart,
      totalAmount: subtotal,
      discount: productDiscount,
      finalAmount: finalTotal,
      address: selectedAddress!,
      status: 'Pending',
      timeline: [{ status: 'Order Placed', date: new Date().toISOString(), note: 'Order has been placed successfully.' }],
      paymentMethod,
      createdAt: Date.now(),
      couponCode: appliedCoupon?.code,
      couponDiscount: couponDiscount
    };

    await setDoc(doc(db, 'orders', order.id), order);
    clearCart();
    setIsProcessing(false);
    navigate('/order-success');
  };

  if(!user) return (
      <PageLayout title="Checkout" showBack>
          <div className="p-8 text-center flex flex-col items-center justify-center h-[60vh]">
              <Info className="w-12 h-12 text-blue-500 mb-4"/>
              <p className="mb-6 font-medium text-gray-700">You need to be logged in to checkout.</p>
              <Button onClick={()=>navigate('/login')} className="w-full max-w-xs">Login Now</Button>
          </div>
      </PageLayout>
  );

  return (
    <PageLayout title="Checkout" showBack showTabs={false}>
      <div className="p-4 space-y-4">
        {/* Address Section */}
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-50">
           <div className="flex justify-between items-center mb-4">
             <h3 className="font-bold text-sm text-gray-900">Delivery Address</h3>
             <button onClick={()=>setShowAddAddress(true)} className="text-blue-600 text-xs font-bold px-3 py-1 bg-blue-50 rounded-full hover:bg-blue-100 transition-colors">Add New</button>
           </div>
           
           {/* Safe Address Rendering */}
           {profile?.addresses?.map(addr => (
             <div key={addr.id} onClick={()=>setSelectedAddress(addr)} className={`p-4 border rounded-xl mb-3 cursor-pointer transition-all ${selectedAddress?.id === addr.id ? 'border-blue-500 bg-blue-50/50 ring-1 ring-blue-500' : 'border-gray-200 hover:border-blue-200'}`}>
               <p className="font-bold text-sm text-gray-900">{addr.fullName} <span className="font-medium text-gray-500 text-xs">({addr.mobile})</span></p>
               <p className="text-xs text-gray-600 mt-1">{addr.street}, {addr.city}, {addr.zipCode}</p>
             </div>
           ))}
           {(!profile?.addresses || profile.addresses.length === 0) && <p className="text-sm text-gray-400 italic">No address found. Please add one.</p>}
        </div>

        {/* Coupon */}
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-50">
           <h3 className="font-bold text-sm mb-3 text-gray-900">Offers & Benefits</h3>
           <div className="flex gap-2">
               <Input placeholder="Enter Coupon Code" value={coupon} onChange={(e)=>setCoupon(e.target.value)} className="uppercase" />
               <Button onClick={handleApplyCoupon} variant="secondary">Apply</Button>
           </div>
           {appliedCoupon && (
               <div className="mt-2 text-xs text-green-600 font-bold flex items-center gap-1">
                   <CheckCircle size={12}/> Coupon {appliedCoupon.code} applied!
               </div>
           )}
        </div>

        {/* Payment Summary (Slip) */}
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-50">
            <h3 className="font-bold text-sm mb-4 text-gray-900">Payment Summary</h3>
            <div className="space-y-3 text-sm">
                <div className="flex justify-between text-gray-500">
                    <span>Total MRP</span>
                    <span>₹{totalMrp}</span>
                </div>
                <div className="flex justify-between text-green-600">
                    <span>Discount on MRP</span>
                    <span>-₹{productDiscount}</span>
                </div>
                {couponDiscount > 0 && (
                     <div className="flex justify-between text-green-600">
                        <span>Coupon Discount</span>
                        <span>-₹{couponDiscount}</span>
                    </div>
                )}
                 <div className="flex justify-between text-gray-500">
                    <span>Delivery Charges</span>
                    <span className="text-green-600">Free</span>
                </div>
                <div className="border-t border-dashed border-gray-200 pt-3 flex justify-between font-bold text-lg text-gray-900">
                    <span>Total Amount</span>
                    <span>₹{finalTotal}</span>
                </div>
            </div>
        </div>

        {/* Payment Method */}
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-50">
           <h3 className="font-bold text-sm mb-3 text-gray-900">Payment Method</h3>
           <div className="space-y-3">
              <label className={`flex items-center gap-3 p-4 border rounded-xl cursor-pointer transition-all ${paymentMethod==='Online' ? 'bg-blue-50 border-blue-200' : 'border-gray-200'}`}>
                 <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${paymentMethod==='Online' ? 'border-blue-600' : 'border-gray-300'}`}>
                    {paymentMethod==='Online' && <div className="w-2.5 h-2.5 rounded-full bg-blue-600"></div>}
                 </div>
                 <input type="radio" name="pay" checked={paymentMethod==='Online'} onChange={()=>setPaymentMethod('Online')} className="hidden" />
                 <span className="text-sm font-bold text-gray-800">Pay via UPI</span>
                 <span className="text-[10px] bg-green-100 text-green-700 px-2 py-0.5 rounded ml-auto">Fastest</span>
              </label>
              {settings?.codEnabled && (
                <label className={`flex items-center gap-3 p-4 border rounded-xl cursor-pointer transition-all ${paymentMethod==='COD' ? 'bg-blue-50 border-blue-200' : 'border-gray-200'}`}>
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${paymentMethod==='COD' ? 'border-blue-600' : 'border-gray-300'}`}>
                        {paymentMethod==='COD' && <div className="w-2.5 h-2.5 rounded-full bg-blue-600"></div>}
                    </div>
                  <input type="radio" name="pay" checked={paymentMethod==='COD'} onChange={()=>setPaymentMethod('COD')} className="hidden" />
                  <span className="text-sm font-bold text-gray-800">Cash on Delivery</span>
                </label>
              )}
           </div>
        </div>
      </div>

      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white/90 backdrop-blur-xl border-t border-gray-100 z-50 pb-safe">
        <Button className="w-full h-12 text-base shadow-lg shadow-blue-200" onClick={handlePlaceOrder} isLoading={isProcessing}>
           {paymentMethod === 'Online' ? `Pay Now ₹${finalTotal}` : `Place Order ₹${finalTotal}`}
        </Button>
      </div>

      <Modal isOpen={showAddAddress} onClose={()=>setShowAddAddress(false)} title="Add Address">
         <div className="space-y-3">
            <Input label="Full Name" onChange={e => setNewAddr({...newAddr, fullName: e.target.value})} />
            <Input label="Mobile" onChange={e => setNewAddr({...newAddr, mobile: e.target.value})} />
            <Input label="Street / Village" onChange={e => setNewAddr({...newAddr, street: e.target.value})} />
            <Input label="Landmark" onChange={e => setNewAddr({...newAddr, landmark: e.target.value})} />
            <div className="flex gap-2">
               <Input label="City/District" onChange={e => setNewAddr({...newAddr, city: e.target.value})} />
               <Input label="State" onChange={e => setNewAddr({...newAddr, state: e.target.value})} />
            </div>
            <Input label="Pincode" onChange={e => setNewAddr({...newAddr, zipCode: e.target.value})} />
            <Button className="w-full mt-4" onClick={handleSaveAddress}>Save Address</Button>
         </div>
      </Modal>
    </PageLayout>
  );
};

const AuthPage = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [agree, setAgree] = useState(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { addToast, settings } = useApp();

  const handleSubmit = async () => {
    try {
      setLoading(true);
      if (isLogin) {
        await signInWithEmailAndPassword(auth, email, password);
      } else {
        if(!agree) {
            setLoading(false);
            return addToast("Agree to terms first", "error");
        }
        const res = await createUserWithEmailAndPassword(auth, email, password);
        const newUser: UserProfile = {
           uid: res.user.uid,
           email: res.user.email || '',
           displayName: name,
           phoneNumber: phone,
           isAdmin: email === 'admin@ioskart.com',
           addresses: [],
           createdAt: Date.now()
        };
        await setDoc(doc(db, 'users', res.user.uid), newUser);
      }
      navigate('/');
    } catch (e: any) {
      addToast(e.message, 'error');
    } finally {
        setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col justify-center p-8 animate-[fade-in_0.5s]">
       <div className="text-center mb-8">
           <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600 mb-2 tracking-tight">{settings?.siteName || 'IosKart'}</h1>
           <p className="text-gray-500 font-medium">{isLogin ? 'Welcome back, you\'ve been missed!' : 'Join us to start shopping'}</p>
       </div>
       
       <div className="space-y-4">
          {!isLogin && (
            <>
            <Input placeholder="Full Name" value={name} onChange={e=>setName(e.target.value)} />
            <Input placeholder="Phone Number" value={phone} onChange={e=>setPhone(e.target.value)} />
            </>
          )}
          <Input placeholder="Email Address" type="email" value={email} onChange={e=>setEmail(e.target.value)} />
          <Input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
          
          {isLogin && <button onClick={async()=> {if(email) await sendPasswordResetEmail(auth, email); addToast('Reset link sent')}} className="text-xs text-blue-600 font-bold text-right w-full hover:underline">Forgot Password?</button>}
          
          {!isLogin && (
            <label className="flex gap-2 items-start py-2">
               <input type="checkbox" className="mt-1 w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" checked={agree} onChange={e=>setAgree(e.target.checked)} />
               <span className="text-xs text-gray-500">I agree to the <Link to="/terms" className="text-blue-600 font-semibold">Terms</Link> and <Link to="/privacy" className="text-blue-600 font-semibold">Privacy Policy</Link>.</span>
            </label>
          )}

          <Button className="w-full h-12 text-base shadow-lg shadow-blue-200 mt-4" onClick={handleSubmit} isLoading={loading}>{isLogin ? 'Login' : 'Create Account'}</Button>
          
          <div className="text-center mt-6">
            <button onClick={()=>setIsLogin(!isLogin)} className="text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors">
               {isLogin ? "Don't have an account? Sign Up" : "Already have an account? Login"}
            </button>
          </div>
       </div>
    </div>
  );
};

const RefundPage = () => {
    const { user, profile, addToast, refreshProfile } = useApp();
    const navigate = useNavigate();
    const [bank, setBank] = useState<BankDetails>({
        accountHolder: profile?.bankDetails?.accountHolder || '',
        accountNumber: profile?.bankDetails?.accountNumber || '',
        ifsc: profile?.bankDetails?.ifsc || '',
        upiId: profile?.bankDetails?.upiId || ''
    });
    const [loading, setLoading] = useState(false);

    if(!user) return <AuthPage />;

    const handleSave = async () => {
        setLoading(true);
        try {
            await updateDoc(doc(db, 'users', user.uid), { bankDetails: bank });
            await refreshProfile();
            addToast("Bank details saved", "success");
            navigate(-1);
        } catch(e) {
            addToast("Error saving details", "error");
        } finally {
            setLoading(false);
        }
    }

    return (
        <PageLayout title="Refund Details" showBack showTabs={false}>
            <div className="p-6 space-y-4">
                <div className="bg-blue-50 p-4 rounded-xl text-sm text-blue-800 mb-4 border border-blue-100">
                    Provide your bank or UPI details to receive refunds for cancelled or returned orders.
                </div>
                <Input label="Account Holder Name" value={bank.accountHolder} onChange={e => setBank({...bank, accountHolder: e.target.value})} />
                <Input label="Account Number" value={bank.accountNumber} onChange={e => setBank({...bank, accountNumber: e.target.value})} />
                <Input label="IFSC Code" value={bank.ifsc} onChange={e => setBank({...bank, ifsc: e.target.value})} />
                <div className="relative">
                    <div className="absolute inset-0 flex items-center justify-center">
                        <span className="bg-gray-50 px-2 text-xs text-gray-400">OR</span>
                    </div>
                    <div className="border-t border-gray-200 my-4"></div>
                </div>
                <Input label="UPI ID" placeholder="user@upi" value={bank.upiId} onChange={e => setBank({...bank, upiId: e.target.value})} />
                <Button className="w-full mt-4" onClick={handleSave} isLoading={loading}>Save Details</Button>
            </div>
        </PageLayout>
    );
};

const ProfilePage = () => {
   const { user, profile, settings } = useApp();
   const navigate = useNavigate();
   const [chatOpen, setChatOpen] = useState(false);
   const [messages, setMessages] = useState<{role: 'user'|'model', text: string}[]>([]);
   const [input, setInput] = useState('');

   const handleChat = async () => {
      if(!input.trim()) return;
      const userMsg = input;
      setMessages(p => [...p, {role: 'user', text: userMsg}]);
      setInput('');
      const response = await getChatResponse(messages.map(m=>m.text), userMsg, settings?.siteName || 'Shop');
      setMessages(p => [...p, {role: 'model', text: response || ''}]);
   };

   if (!user) return <AuthPage />;

   return (
      <PageLayout title="Profile" showTabs={true}>
         <div className="bg-white p-6 mb-6 shadow-[0_4px_20px_-10px_rgba(0,0,0,0.1)]">
            <div className="flex items-center gap-5">
               <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center text-3xl font-bold text-blue-600 shadow-inner">
                  {profile?.displayName?.charAt(0)}
               </div>
               <div>
                  <h2 className="text-2xl font-bold text-gray-900">{profile?.displayName}</h2>
                  <p className="text-sm text-gray-500 font-medium">{profile?.email}</p>
                  <div className="mt-1 flex items-center gap-1">
                      <Badge color="bg-gray-100 text-gray-600">User</Badge>
                      {profile?.isAdmin && <Badge color="bg-black text-white">Admin</Badge>}
                  </div>
               </div>
            </div>
            {profile?.isAdmin && (
              <Button className="w-full mt-6 bg-gray-900 text-white shadow-gray-300" onClick={()=>navigate('/admin')}>Open Admin Panel</Button>
            )}
         </div>

         <div className="px-4 grid grid-cols-2 gap-4 mb-6">
             {[
                 {title: 'My Orders', icon: Truck, path: '/orders'},
                 {title: 'Refunds', icon: Banknote, path: '/refunds'},
                 {title: 'Addresses', icon: MapPin, path: '/addresses'}, 
                 {title: 'AI Support', icon: Smartphone, action: () => setChatOpen(true)}
             ].map((item: any, i) => (
                 <div key={i} onClick={item.path ? ()=>navigate(item.path) : item.action} className="bg-white p-5 rounded-2xl shadow-sm border border-gray-50 flex flex-col items-center gap-3 active:scale-95 transition-all duration-200 cursor-pointer hover:shadow-md">
                    <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center text-blue-600">
                        <item.icon size={20} strokeWidth={2.5}/>
                    </div>
                    <span className="text-sm font-semibold text-gray-800">{item.title}</span>
                 </div>
             ))}
         </div>

         <div className="px-4 space-y-3">
            <h3 className="font-bold text-sm text-gray-900 ml-1">General</h3>
            <Link to="/about" className="block p-4 bg-white rounded-2xl text-sm font-medium text-gray-700 shadow-sm border border-gray-50 hover:bg-gray-50 transition-colors">About Us</Link>
            <Link to="/privacy" className="block p-4 bg-white rounded-2xl text-sm font-medium text-gray-700 shadow-sm border border-gray-50 hover:bg-gray-50 transition-colors">Privacy Policy</Link>
            <Link to="/terms" className="block p-4 bg-white rounded-2xl text-sm font-medium text-gray-700 shadow-sm border border-gray-50 hover:bg-gray-50 transition-colors">Terms & Conditions</Link>
            <Link to="/refund-policy" className="block p-4 bg-white rounded-2xl text-sm font-medium text-gray-700 shadow-sm border border-gray-50 hover:bg-gray-50 transition-colors">Refund Policy</Link>
            <button onClick={()=>signOut(auth)} className="w-full p-4 bg-red-50 rounded-2xl text-sm font-bold text-red-600 flex items-center justify-center gap-2 shadow-sm border border-red-100 mt-6 active:bg-red-100 transition-colors">
               <LogOut size={18}/> Logout
            </button>
         </div>

         <Modal isOpen={chatOpen} onClose={()=>setChatOpen(false)} title="AI Support Chat">
            <div className="h-80 overflow-y-auto mb-4 space-y-3 p-2 bg-gray-50 rounded-2xl">
               {messages.map((m, i) => (
                  <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                     <div className={`max-w-[85%] px-4 py-2.5 rounded-2xl text-sm leading-relaxed shadow-sm ${m.role==='user'?'bg-blue-600 text-white rounded-tr-none':'bg-white text-gray-800 rounded-tl-none border border-gray-100'}`}>
                        {m.text}
                     </div>
                  </div>
               ))}
               {messages.length === 0 && (
                   <div className="flex flex-col items-center justify-center h-full text-gray-400 gap-2">
                       <Smartphone size={32} className="opacity-20"/>
                       <p className="text-xs">Ask me about your orders, returns, or products!</p>
                   </div>
               )}
            </div>
            <div className="flex gap-2">
               <Input value={input} onChange={e=>setInput(e.target.value)} placeholder="Type your question..." className="rounded-full" />
               <button onClick={handleChat} className="bg-blue-600 text-white p-3 rounded-full hover:bg-blue-700 shadow-lg shadow-blue-200 transition-transform active:scale-95"><Send size={18}/></button>
            </div>
         </Modal>
      </PageLayout>
   );
};

const OrderDetailPage = () => {
    const { id } = useParams();
    const { user } = useApp();
    const [order, setOrder] = useState<Order | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (!user || !id) return;
        const fetchOrder = async () => {
            try {
                const snap = await getDoc(doc(db, 'orders', id));
                if (snap.exists()) {
                    setOrder({ id: snap.id, ...snap.data() } as Order);
                }
            } catch (error) {
                console.error("Error fetching order", error);
            } finally {
                setLoading(false);
            }
        };
        fetchOrder();
    }, [id, user]);

    if (loading) return <div className="flex justify-center h-screen items-center"><Loader2 className="animate-spin text-blue-600" /></div>;
    if (!order) return <div className="p-8 text-center text-gray-500">Order not found.</div>;

    const timelineSteps = [
        { status: 'Order Placed', label: 'Order Placed' },
        { status: 'Processing', label: 'Processing' },
        { status: 'Shipped', label: 'Shipped' },
        { status: 'Delivered', label: 'Delivered' }
    ];

    const currentStatusIndex = timelineSteps.findIndex(s => s.status === order.status);
    const isCancelled = order.status === 'Cancelled';
    const isRefunded = order.status === 'Refunded';

    return (
        <PageLayout title={`Order #${order.id.slice(-6)}`} showBack showTabs={false}>
            <div className="p-4 space-y-6">
                
                {/* Timeline Animation */}
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-50">
                    <h3 className="font-bold text-gray-900 mb-6">Order Status</h3>
                    
                    {isCancelled || isRefunded ? (
                        <div className="flex items-center gap-3 text-red-600 bg-red-50 p-4 rounded-xl">
                             <AlertCircle size={24} />
                             <span className="font-bold">Order {order.status}</span>
                        </div>
                    ) : (
                        <div className="relative pl-4 space-y-8">
                            {/* Vertical Line */}
                            <div className="absolute top-2 left-[23px] bottom-2 w-0.5 bg-gray-100"></div>

                            {timelineSteps.map((step, index) => {
                                const isCompleted = index <= currentStatusIndex;
                                const isCurrent = index === currentStatusIndex;
                                const stepData = order.timeline.find(t => t.status === step.status);

                                return (
                                    <div key={step.status} className="relative flex gap-4 items-start z-10">
                                        <div className={`w-6 h-6 rounded-full flex items-center justify-center border-2 transition-all duration-500 ${isCompleted ? 'bg-green-500 border-green-500 text-white' : 'bg-white border-gray-200 text-transparent'} ${isCurrent ? 'ring-4 ring-green-100' : ''}`}>
                                            {isCompleted && <CheckCircle size={14} strokeWidth={3} />}
                                        </div>
                                        <div className="flex-1 -mt-1">
                                            <p className={`text-sm font-bold ${isCompleted ? 'text-gray-900' : 'text-gray-400'}`}>{step.label}</p>
                                            {stepData && (
                                                <div className="animate-[fade-in_0.5s]">
                                                    <p className="text-xs text-gray-500 mt-1">{new Date(stepData.date).toLocaleString()}</p>
                                                    {stepData.note && <p className="text-xs text-gray-600 mt-1 bg-gray-50 p-2 rounded-lg inline-block border border-gray-100">{stepData.note}</p>}
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    )}
                </div>

                {/* Order Details */}
                <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-50">
                     <h3 className="font-bold text-sm mb-4">Items</h3>
                     <div className="space-y-3">
                        {order.items.map(item => (
                            <div key={item.cartItemId} className="flex gap-3">
                                <img src={item.images?.[0]} className="w-16 h-16 rounded-xl bg-gray-50 object-cover" alt={item.name}/>
                                <div>
                                    <p className="font-medium text-sm text-gray-900 line-clamp-1">{item.name}</p>
                                    <p className="text-xs text-gray-500 mt-1">Size: {item.selectedSize || 'N/A'} | Qty: {item.quantity}</p>
                                    <p className="text-sm font-bold text-gray-900 mt-1">₹{item.price}</p>
                                </div>
                            </div>
                        ))}
                     </div>
                </div>

                <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-50">
                    <h3 className="font-bold text-sm mb-2">Shipping Details</h3>
                    <p className="text-sm font-bold text-gray-800">{order.address.fullName}</p>
                    <p className="text-sm text-gray-600">{order.address.street}, {order.address.city}, {order.address.state} - {order.address.zipCode}</p>
                    <p className="text-sm text-gray-600 mt-1">Mobile: {order.address.mobile}</p>
                </div>

                <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-50 flex justify-between items-center">
                    <span className="font-bold text-gray-900">Total Amount</span>
                    <span className="font-bold text-xl text-blue-600">₹{order.finalAmount}</span>
                </div>
            </div>
        </PageLayout>
    );
};

const OrdersPage = () => {
    const { user } = useApp();
    const [orders, setOrders] = useState<Order[]>([]);
    const navigate = useNavigate();

    useEffect(() => {
        if(!user) return;
        const fetchOrders = async () => {
            const q = query(collection(db, 'orders'), where('uid', '==', user.uid));
            const snap = await getDocs(q);
            setOrders(snap.docs.map(d => d.data() as Order).sort((a,b) => b.createdAt - a.createdAt));
        };
        fetchOrders();
    }, [user]);

    if(!user) return <AuthPage />;

    return (
        <PageLayout title="My Orders" showTabs={true}>
            <div className="p-4 space-y-4">
                {orders.map(order => (
                    <div key={order.id} className="bg-white rounded-2xl p-4 shadow-sm border border-gray-50">
                        <div className="flex justify-between items-start mb-3">
                            <div>
                                <h3 className="font-bold text-gray-900">Order #{order.id.slice(-6)}</h3>
                                <p className="text-xs text-gray-500">{new Date(order.createdAt).toLocaleDateString()}</p>
                            </div>
                            <Badge color={order.status === 'Delivered' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}>{order.status}</Badge>
                        </div>
                        <div className="space-y-2 mb-3">
                            {order.items.slice(0, 2).map(item => (
                                <div key={item.cartItemId} className="flex gap-3">
                                    <img src={item.images?.[0]} className="w-12 h-12 rounded-lg bg-gray-100 object-cover" />
                                    <div>
                                        <p className="text-sm font-medium line-clamp-1">{item.name}</p>
                                        <p className="text-xs text-gray-500">Qty: {item.quantity} {item.selectedSize ? `| Size: ${item.selectedSize}` : ''}</p>
                                    </div>
                                </div>
                            ))}
                            {order.items.length > 2 && <p className="text-xs text-gray-500 ml-1">+{order.items.length - 2} more items</p>}
                        </div>
                        <div className="border-t border-gray-100 pt-3 flex justify-between items-center">
                            <span className="font-bold text-gray-900">₹{order.finalAmount}</span>
                            <button onClick={()=>navigate(`/order/${order.id}`)} className="text-blue-600 text-sm font-medium bg-blue-50 px-3 py-1.5 rounded-lg active:scale-95 transition-transform">View Details</button>
                        </div>
                    </div>
                ))}
                {!orders.length && (
                    <div className="text-center py-20">
                         <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4 text-gray-400">
                             <Truck size={32}/>
                         </div>
                         <h3 className="font-bold text-gray-900">No orders yet</h3>
                         <p className="text-gray-500 text-sm mt-1">Start shopping to see your orders here.</p>
                    </div>
                )}
            </div>
        </PageLayout>
    );
}

export const ClientRoutes = () => (
   <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/categories" element={<CategoriesPage />} />
      <Route path="/search" element={<CategoryResultsPage />} />
      <Route path="/product/:id" element={<ProductPage />} />
      <Route path="/cart" element={<CartPage />} />
      <Route path="/checkout" element={<CheckoutPage />} />
      <Route path="/login" element={<AuthPage />} />
      <Route path="/profile" element={<ProfilePage />} />
      <Route path="/addresses" element={<AddressesPage />} />
      <Route path="/orders" element={<OrdersPage />} />
      <Route path="/order/:id" element={<OrderDetailPage />} />
      <Route path="/refunds" element={<RefundPage />} />
      <Route path="/privacy" element={<InfoPage title="Privacy Policy" contentKey="privacyPolicy"/>} />
      <Route path="/terms" element={<InfoPage title="Terms & Conditions" contentKey="termsConditions"/>} />
      <Route path="/refund-policy" element={<InfoPage title="Refund Policy" contentKey="refundPolicy"/>} />
      <Route path="/about" element={<PageLayout title="About Us" showBack showTabs={false}><div className="p-6 text-center text-gray-600"><Shield className="w-16 h-16 mx-auto mb-4 text-blue-500"/><p>We are a premium e-commerce store dedicated to providing the best quality products.</p></div></PageLayout>} />
      <Route path="/order-success" element={
        <PageLayout showTabs={false} hideCart>
            <div className="h-[80vh] flex flex-col items-center justify-center bg-gray-50 px-4 text-center">
                <div className="w-24 h-24 bg-yellow-50 rounded-full flex items-center justify-center mb-6 animate-pulse">
                     <Clock className="w-12 h-12 text-yellow-600 animate-[spin_3s_linear_infinite]" />
                </div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">Order Pending</h1>
                <p className="text-gray-500 mb-8 max-w-xs">Your order has been placed and is waiting for approval. You can track the status in your orders.</p>
                <div className="flex gap-4 w-full max-w-xs">
                    <Button variant="secondary" onClick={()=>window.location.hash='#/'} className="flex-1">Home</Button>
                    <Button onClick={()=>window.location.hash='#/orders'} className="flex-1">View Orders</Button>
                </div>
            </div>
        </PageLayout>
      } />
   </Routes>
);