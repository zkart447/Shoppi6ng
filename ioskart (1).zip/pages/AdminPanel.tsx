import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useNavigate, useLocation } from 'react-router-dom';
import { LayoutDashboard, Users, ShoppingCart, Package, Settings, Search, Edit, Trash, Save, Menu, X, Plus, Image as ImageIcon, Star, LogOut, Ticket, FileText, Ban, Lock, Unlock, Sparkles, Loader2, Layers } from 'lucide-react';
import { useApp } from '../store';
import { Button, Input, Modal, Badge, ConfirmModal } from '../components/Shared';
import { collection, getDocs, doc, updateDoc, deleteDoc, addDoc, query, where, orderBy, setDoc, onSnapshot } from 'firebase/firestore';
import { db, auth } from '../firebase';
import { signOut } from 'firebase/auth';
import { Product, Order, UserProfile, Category, Review, Coupon } from '../types';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { generateProductMetadata, generateProductImage, generateBulkProductMetadata } from '../geminiService';

const AdminLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    const location = useLocation();
    const navigate = useNavigate();

    // Close sidebar on route change
    useEffect(() => {
        setIsSidebarOpen(false);
    }, [location]);

    const handleLogout = async () => {
        await signOut(auth);
        navigate('/');
    };

    return (
        <div className="flex min-h-screen bg-gray-100">
            {/* Mobile Header */}
            <div className="md:hidden fixed top-0 left-0 right-0 h-16 bg-white border-b border-gray-200 z-30 flex items-center px-4 justify-between shadow-sm">
                <h1 className="text-lg font-bold text-gray-900">Admin Panel</h1>
                <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-2 text-gray-700">
                    {isSidebarOpen ? <X size={24} /> : <Menu size={24} />}
                </button>
            </div>

            {/* Sidebar */}
            <aside className={`fixed inset-y-0 left-0 w-64 bg-white border-r border-gray-200 z-40 transform transition-transform duration-300 md:translate-x-0 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:static md:block shadow-xl md:shadow-none flex flex-col`}>
                <div className="p-6 border-b hidden md:block">
                    <h1 className="text-xl font-bold text-gray-900">Admin Panel</h1>
                </div>
                <nav className="p-4 space-y-1 mt-16 md:mt-0 flex-1">
                    <NavLink to="/admin" icon={<LayoutDashboard size={20} />} label="Dashboard" />
                    <NavLink to="/admin/orders" icon={<ShoppingCart size={20} />} label="Orders" />
                    <NavLink to="/admin/products" icon={<Package size={20} />} label="Products" />
                    <NavLink to="/admin/categories" icon={<ImageIcon size={20} />} label="Categories" />
                    <NavLink to="/admin/users" icon={<Users size={20} />} label="Users" />
                    <NavLink to="/admin/settings" icon={<Settings size={20} />} label="Settings" />
                </nav>
                <div className="p-4 border-t">
                    <button onClick={handleLogout} className="flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-lg text-red-600 hover:bg-red-50 w-full transition-colors">
                        <LogOut size={20} /> <span>Logout</span>
                    </button>
                </div>
            </aside>

            {/* Overlay */}
            {isSidebarOpen && <div className="fixed inset-0 bg-black/50 z-30 md:hidden" onClick={() => setIsSidebarOpen(false)}></div>}

            <main className="flex-1 p-4 pt-20 md:p-8 overflow-y-auto w-full">
                {children}
            </main>
        </div>
    );
};

const NavLink = ({ to, icon, label }: any) => {
    const location = useLocation();
    const isActive = location.pathname === to;
    return (
        <Link to={to} className={`flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-lg transition-colors ${isActive ? 'bg-blue-50 text-blue-600' : 'text-gray-700 hover:bg-gray-50'}`}>
            {icon} <span>{label}</span>
        </Link>
    );
};

const Dashboard = () => {
  const [stats, setStats] = useState({ users: 0, orders: 0, revenue: 0 });
  const [data, setData] = useState<any[]>([]);

  useEffect(() => {
    // Real-time listener for Orders
    const unsubOrders = onSnapshot(collection(db, 'orders'), (snapshot) => {
        let rev = 0;
        snapshot.docs.forEach(d => { rev += d.data().finalAmount || 0 });
        setStats(prev => ({ ...prev, orders: snapshot.size, revenue: rev }));
        setData(prev => {
            const newData = [...prev];
            const idx = newData.findIndex(i => i.name === 'Orders');
            if(idx > -1) {
                newData[idx] = { ...newData[idx], value: snapshot.size };
            } else {
                newData.push({ name: 'Orders', value: snapshot.size });
            }
            return newData;
        });
    });

    // Real-time listener for Users
    const unsubUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
        setStats(prev => ({ ...prev, users: snapshot.size }));
        setData(prev => {
            const newData = [...prev];
            const idx = newData.findIndex(i => i.name === 'Users');
            if(idx > -1) {
                newData[idx] = { ...newData[idx], value: snapshot.size };
            } else {
                newData.push({ name: 'Users', value: snapshot.size });
            }
            return newData;
        });
    });

    return () => {
        unsubOrders();
        unsubUsers();
    };
  }, []);

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6">Dashboard</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
         <StatCard title="Total Users" value={stats.users} icon={<Users className="text-blue-500" />} />
         <StatCard title="Total Orders" value={stats.orders} icon={<ShoppingCart className="text-green-500" />} />
         <StatCard title="Total Revenue" value={`₹${stats.revenue.toLocaleString()}`} icon={<div className="font-bold text-yellow-500">₹</div>} />
      </div>
      <div className="bg-white p-6 rounded-2xl shadow-sm h-80">
         <h3 className="font-bold mb-4">Overview</h3>
         <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data}>
               <XAxis dataKey="name" />
               <YAxis />
               <Tooltip />
               <Bar dataKey="value" fill="#3b82f6" radius={[4,4,0,0]} />
            </BarChart>
         </ResponsiveContainer>
      </div>
    </div>
  );
};

const StatCard = ({ title, value, icon }: any) => (
  <div className="bg-white p-6 rounded-2xl shadow-sm flex items-center justify-between">
     <div>
        <p className="text-sm text-gray-500 font-medium">{title}</p>
        <p className="text-3xl font-bold text-gray-900 mt-2">{value}</p>
     </div>
     <div className="w-12 h-12 bg-gray-50 rounded-full flex items-center justify-center">
         {icon}
     </div>
  </div>
);

const UsersScreen = () => {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [search, setSearch] = useState('');
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [userOrders, setUserOrders] = useState<Order[]>([]);
  const { addToast } = useApp();
  
  const [deleteId, setDeleteId] = useState<string|null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    // Real-time updates for users list to ensure consistency
    const unsub = onSnapshot(collection(db, 'users'), (snapshot) => {
        setUsers(snapshot.docs.map(d => ({...d.data(), uid: d.id} as UserProfile)));
    });
    return () => unsub();
  }, []);

  useEffect(() => {
      if(selectedUser) {
          const fetchOrders = async () => {
              try {
                const q = query(collection(db, 'orders'), where('uid', '==', selectedUser.uid));
                const snap = await getDocs(q);
                setUserOrders(snap.docs.map(d => d.data() as Order).sort((a,b) => b.createdAt - a.createdAt));
              } catch(e) { console.error(e) }
          };
          fetchOrders();
      }
  }, [selectedUser]);

  const handleBlockUser = async () => {
      if(!selectedUser) return;
      const newStatus = !selectedUser.isBlocked;
      await updateDoc(doc(db, 'users', selectedUser.uid), { isBlocked: newStatus });
      setSelectedUser(prev => prev ? { ...prev, isBlocked: newStatus } : null);
      addToast(newStatus ? "User Blocked" : "User Unblocked", "success");
  };

  const confirmDelete = async () => {
      if(!deleteId) return;
      setIsDeleting(true);
      try {
        await deleteDoc(doc(db, 'users', deleteId));
        if(selectedUser?.uid === deleteId) setSelectedUser(null);
        addToast("User Deleted", "success");
      } catch (e: any) {
        if(e.code === 'permission-denied') {
            addToast("Permission Denied: Check Firebase Rules", "error");
        } else {
            addToast("Failed to delete user", "error");
        }
      } finally {
        setIsDeleting(false);
        setDeleteId(null);
      }
  }

  const filtered = users.filter(u => u.uid.includes(search) || u.displayName?.toLowerCase().includes(search.toLowerCase()) || u.email?.includes(search));

  return (
     <div>
        <h2 className="text-2xl font-bold mb-4">Users</h2>
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
           <div className="p-4 border-b">
              <Input placeholder="Search by Name, Email or UID" value={search} onChange={e=>setSearch(e.target.value)} />
           </div>
           <div className="overflow-x-auto">
               <table className="w-full text-sm text-left">
                  <thead className="bg-gray-50 text-gray-500">
                     <tr>
                        <th className="p-4">User</th>
                        <th className="p-4 hidden sm:table-cell">UID</th>
                        <th className="p-4">Status</th>
                        <th className="p-4">Action</th>
                     </tr>
                  </thead>
                  <tbody>
                     {filtered.map(u => (
                        <tr key={u.uid} className="border-t hover:bg-gray-50">
                           <td className="p-4">
                              <div className="font-medium">{u.displayName}</div>
                              <div className="text-gray-500 text-xs">{u.email}</div>
                           </td>
                           <td className="p-4 hidden sm:table-cell font-mono text-xs text-gray-500">{u.uid}</td>
                           <td className="p-4">
                               {u.isBlocked ? <Badge color="bg-red-100 text-red-600">Blocked</Badge> : <Badge color="bg-green-100 text-green-600">Active</Badge>}
                           </td>
                           <td className="p-4"><Button variant="secondary" size="sm" onClick={()=>setSelectedUser(u)}>View</Button></td>
                        </tr>
                     ))}
                  </tbody>
               </table>
           </div>
        </div>
        <Modal isOpen={!!selectedUser} onClose={()=>setSelectedUser(null)} title="User Details">
           {selectedUser && (
              <div className="space-y-4">
                 <div className="flex justify-between items-start">
                     <div>
                        <p><strong>Name:</strong> {selectedUser.displayName}</p>
                        <p><strong>Email:</strong> {selectedUser.email}</p>
                        <p><strong>Phone:</strong> {selectedUser.phoneNumber || 'N/A'}</p>
                     </div>
                     <div className="flex gap-2">
                        <button onClick={handleBlockUser} className={`p-2 rounded-lg ${selectedUser.isBlocked ? 'bg-green-100 text-green-600' : 'bg-yellow-100 text-yellow-600'}`}>
                            {selectedUser.isBlocked ? <Unlock size={18}/> : <Ban size={18}/>}
                        </button>
                        <button onClick={() => setDeleteId(selectedUser.uid)} className="p-2 bg-red-100 text-red-600 rounded-lg">
                            <Trash size={18}/>
                        </button>
                     </div>
                 </div>
                 
                 <div className="bg-gray-50 p-3 rounded-lg border border-gray-100">
                    <p className="font-bold text-xs uppercase text-gray-500 mb-2">Saved Addresses</p>
                    {selectedUser.addresses?.map(a => (
                       <p key={a.id} className="text-sm mb-1 pb-1 border-b border-gray-200 last:border-0">{a.fullName}, {a.city} - {a.zipCode}</p>
                    ))}
                    {!selectedUser.addresses?.length && <p className="text-xs text-gray-400">No addresses saved</p>}
                 </div>

                 <div className="bg-gray-50 p-3 rounded-lg border border-gray-100 max-h-40 overflow-y-auto">
                    <p className="font-bold text-xs uppercase text-gray-500 mb-2">Order History</p>
                    {userOrders.map(o => (
                        <div key={o.id} className="text-sm border-b border-gray-200 pb-2 mb-2 last:border-0 last:mb-0">
                            <div className="flex justify-between">
                                <span className="font-medium">{o.id}</span>
                                <Badge color="bg-gray-200 text-gray-700 text-[10px]">{o.status}</Badge>
                            </div>
                            <p className="text-xs text-gray-500">₹{o.finalAmount} • {new Date(o.createdAt).toLocaleDateString()}</p>
                        </div>
                    ))}
                    {!userOrders.length && <p className="text-xs text-gray-400">No orders found.</p>}
                 </div>

                 <div className="bg-blue-50 p-3 rounded-lg border border-blue-100">
                    <p className="font-bold text-xs uppercase text-blue-500 mb-2">Bank / Refund Details</p>
                    {selectedUser.bankDetails ? (
                        <div className="text-sm space-y-1">
                            <p><span className="font-medium">Holder:</span> {selectedUser.bankDetails.accountHolder}</p>
                            <p><span className="font-medium">Acc No:</span> {selectedUser.bankDetails.accountNumber}</p>
                            <p><span className="font-medium">IFSC:</span> {selectedUser.bankDetails.ifsc}</p>
                            <p><span className="font-medium">UPI:</span> {selectedUser.bankDetails.upiId}</p>
                        </div>
                    ) : (
                        <p className="text-xs text-gray-400">No bank details provided</p>
                    )}
                 </div>
              </div>
           )}
        </Modal>
        <ConfirmModal 
            isOpen={!!deleteId} 
            onClose={() => setDeleteId(null)} 
            onConfirm={confirmDelete}
            title="Delete User"
            message="Are you sure you want to delete this user? This cannot be undone."
            isLoading={isDeleting}
        />
     </div>
  );
};

const ProductsScreen = () => {
    const { addToast } = useApp();
    const [products, setProducts] = useState<Product[]>([]);
    const [categories, setCategories] = useState<Category[]>([]);
    const [editing, setEditing] = useState<Partial<Product> | null>(null);
    const [searchTerm, setSearchTerm] = useState('');
    const [newReview, setNewReview] = useState<Partial<Review>>({});
    
    // AI State
    const [showAiModal, setShowAiModal] = useState(false);
    const [aiPrompt, setAiPrompt] = useState('');
    const [aiReviewCount, setAiReviewCount] = useState(5);
    const [isAiGenerating, setIsAiGenerating] = useState(false);

    // Bulk AI State
    const [showBulkModal, setShowBulkModal] = useState(false);
    const [bulkTopic, setBulkTopic] = useState('');
    const [bulkCount, setBulkCount] = useState(3);
    const [isBulkGenerating, setIsBulkGenerating] = useState(false);
    const [bulkProgress, setBulkProgress] = useState('');

    // Delete State
    const [deleteId, setDeleteId] = useState<string|null>(null);
    const [isDeleting, setIsDeleting] = useState(false);

    useEffect(() => {
        const fetch = async () => {
            const pSnap = await getDocs(collection(db, 'products'));
            setProducts(pSnap.docs.map(d => ({ id: d.id, ...d.data() } as Product)));
            const cSnap = await getDocs(collection(db, 'categories'));
            setCategories(cSnap.docs.map(d => ({ id: d.id, ...d.data() } as Category)));
        };
        fetch();
    }, []);

    const handleSave = async () => {
        if (!editing || !editing.name || !editing.price) return addToast('Missing fields', 'error');
        
        try {
            // Sanitize and ensure types
            const cleanReviews = (editing.reviews || []).map(r => ({
                id: r.id || Date.now().toString() + Math.random(),
                userName: r.userName || 'Anonymous',
                userImage: r.userImage || 'https://ui-avatars.com/api/?name=Anon',
                rating: Number(r.rating) || 5,
                text: r.text || '',
                date: r.date || new Date().toISOString()
            }));

            const dataToSave = {
                name: editing.name,
                categoryId: editing.categoryId || '',
                description: editing.description || '',
                price: Number(editing.price),
                mrp: Number(editing.mrp) || Number(editing.price),
                images: editing.images || [],
                rating: 0,
                isTrusted: !!editing.isTrusted,
                freeDelivery: !!editing.freeDelivery,
                reviews: cleanReviews,
                stock: 100,
                sizes: editing.sizes || [],
                updatedAt: Date.now()
            };
            
            // Calculate avg rating
            if (cleanReviews.length > 0) {
                const total = cleanReviews.reduce((acc, r) => acc + r.rating, 0);
                dataToSave.rating = Math.round(total / cleanReviews.length);
            }

            if (editing.id) {
                await updateDoc(doc(db, 'products', editing.id), dataToSave);
                setProducts(prev => prev.map(p => p.id === editing.id ? { ...p, ...dataToSave, id: editing.id! } as Product : p));
                addToast('Product updated', 'success');
            } else {
                const res = await addDoc(collection(db, 'products'), { ...dataToSave, createdAt: Date.now() });
                setProducts(prev => [...prev, { id: res.id, ...dataToSave, createdAt: Date.now() } as Product]);
                addToast('Product created', 'success');
            }
            setEditing(null);
        } catch (e: any) {
            if(e.code === 'resource-exhausted') {
                addToast('Data too large (Reduce images)', 'error');
            } else {
                addToast('Error saving product', 'error');
            }
            console.error(e);
        }
    };

    const confirmDelete = async () => {
        if(!deleteId) return;
        setIsDeleting(true);
        try {
            await deleteDoc(doc(db, 'products', deleteId));
            setProducts(prev => prev.filter(p => p.id !== deleteId));
            addToast('Product deleted', 'success');
        } catch (error: any) {
             if(error.code === 'permission-denied') {
                addToast("Permission Denied: Check Firebase Rules", "error");
            } else {
                addToast("Failed to delete product", "error");
            }
        } finally {
            setIsDeleting(false);
            setDeleteId(null);
        }
    }

    const addFakeReview = () => {
        if(!newReview.userName || !newReview.text) return;
        const review: Review = {
            id: Date.now().toString(),
            userName: newReview.userName,
            userImage: newReview.userImage || `https://ui-avatars.com/api/?name=${newReview.userName}`,
            text: newReview.text,
            rating: newReview.rating || 5,
            date: new Date().toISOString()
        };
        setEditing(prev => ({ ...prev, reviews: [...(prev?.reviews || []), review] }));
        setNewReview({});
    };

    const handleGenerateAi = async () => {
        if(!aiPrompt) return addToast("Please enter a description", "error");
        setIsAiGenerating(true);
        try {
            const metadata = await generateProductMetadata(aiPrompt, aiReviewCount);
            const image = await generateProductImage(aiPrompt);

            if(metadata) {
                const productData: Partial<Product> = {
                    name: metadata.name,
                    description: metadata.description,
                    price: metadata.price,
                    mrp: metadata.mrp,
                    sizes: metadata.sizes || ['S','M','L','XL'],
                    reviews: metadata.reviews || [],
                    isTrusted: true,
                    freeDelivery: true,
                    images: image ? [image] : []
                };
                
                if(categories.length > 0) productData.categoryId = categories[0].id;

                setEditing(productData);
                setShowAiModal(false);
                addToast("Product Generated! Please review and save.", "success");
            } else {
                addToast("Failed to generate content", "error");
            }
        } catch (error) {
            console.error(error);
            addToast("AI Generation Failed", "error");
        } finally {
            setIsAiGenerating(false);
        }
    }

    const handleBulkGenerate = async () => {
        if(!bulkTopic) return addToast("Topic is required", "error");
        if(bulkCount < 1 || bulkCount > 5) return addToast("Quantity must be 1-5", "error");
        
        setIsBulkGenerating(true);
        setBulkProgress("Generating product concepts...");

        try {
            // 1. Generate Metadata for all
            const items = await generateBulkProductMetadata(bulkTopic, bulkCount);
            if(!items || items.length === 0) throw new Error("Failed to generate metadata");

            // 2. Loop through and generate images + save
            let savedCount = 0;
            for(const item of items) {
                savedCount++;
                setBulkProgress(`Generating Image & Saving ${savedCount}/${items.length}...`);
                
                // Generate Image (Now returns compressed base64)
                const image = await generateProductImage(item.name);
                
                // Clean Data
                const cleanReviews = (item.reviews || []).map((r: any) => ({
                    id: Date.now().toString() + Math.random(),
                    userName: r.userName || 'Customer',
                    userImage: r.userImage || `https://ui-avatars.com/api/?name=${r.userName}`,
                    rating: Number(r.rating) || 5,
                    text: r.text || 'Good Product',
                    date: new Date().toISOString()
                }));

                let rating = 0;
                if(cleanReviews.length > 0) {
                     rating = Math.round(cleanReviews.reduce((acc: number, r: any) => acc + r.rating, 0) / cleanReviews.length);
                }

                const dataToSave = {
                    name: item.name,
                    categoryId: categories.length > 0 ? categories[0].id : '',
                    description: item.description,
                    price: Number(item.price),
                    mrp: Number(item.mrp),
                    images: image ? [image] : [],
                    rating: rating,
                    isTrusted: true,
                    freeDelivery: true,
                    reviews: cleanReviews,
                    stock: 50,
                    sizes: item.sizes || ['S', 'M', 'L'],
                    createdAt: Date.now(),
                    updatedAt: Date.now()
                };

                const res = await addDoc(collection(db, 'products'), dataToSave);
                setProducts(prev => [...prev, { id: res.id, ...dataToSave } as Product]);
            }

            addToast(`Successfully added ${savedCount} products!`, "success");
            setShowBulkModal(false);
            setBulkTopic('');
            setBulkCount(3);

        } catch(e: any) {
            console.error(e);
            if(e.code === 'resource-exhausted') {
                addToast("Data too large for some products.", "error");
            } else {
                addToast("Bulk generation failed in between.", "error");
            }
        } finally {
            setIsBulkGenerating(false);
            setBulkProgress("");
        }
    };

    const filtered = products.filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()));

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">Products</h2>
                <div className="flex gap-2">
                    <Button variant="secondary" onClick={() => setShowBulkModal(true)}>
                         <Layers size={18} className="mr-2 text-indigo-600" /> Bulk AI
                    </Button>
                    <Button variant="secondary" onClick={() => setShowAiModal(true)}>
                         <Sparkles size={18} className="mr-2 text-purple-600" /> Add with AI
                    </Button>
                    <Button onClick={() => setEditing({ images: [], reviews: [], isTrusted: false, freeDelivery: false, sizes: [] })}>
                        <Plus size={18} className="mr-2" /> Add Product
                    </Button>
                </div>
            </div>

            <div className="bg-white p-4 rounded-xl shadow-sm mb-4">
                <Input placeholder="Search Products..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filtered.map(p => (
                    <div key={p.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col gap-2">
                        <div className="flex gap-4">
                            <img src={p.images?.[0]} className="w-16 h-16 rounded-lg bg-gray-100 object-cover" />
                            <div>
                                <h3 className="font-bold text-gray-900 line-clamp-1">{p.name}</h3>
                                <p className="text-sm text-gray-500">₹{p.price}</p>
                            </div>
                        </div>
                        <div className="flex justify-end gap-2 mt-2">
                            <Button variant="outline" className="px-2 py-1 text-xs" onClick={() => setEditing(p)}>Edit</Button>
                            <Button variant="danger" className="px-2 py-1 text-xs" onClick={() => setDeleteId(p.id)}><Trash size={14}/></Button>
                        </div>
                    </div>
                ))}
            </div>

            {/* Single AI Modal */}
            <Modal isOpen={showAiModal} onClose={() => setShowAiModal(false)} title="Generate Product with AI">
                <div className="space-y-4">
                    <div className="flex flex-col gap-1">
                        <label className="text-xs font-medium text-gray-500 ml-1">Product Description</label>
                        <textarea 
                            className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" 
                            rows={4} 
                            placeholder="e.g., A premium leather jacket for men, dark brown color, winter wear..."
                            value={aiPrompt} 
                            onChange={e => setAiPrompt(e.target.value)}
                        ></textarea>
                    </div>
                    <Input label="Number of Reviews to Generate" type="number" value={aiReviewCount} onChange={e => setAiReviewCount(Number(e.target.value))} />
                    <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white" onClick={handleGenerateAi} isLoading={isAiGenerating}>
                        <Sparkles size={18} className="mr-2" /> Generate Details & Image
                    </Button>
                </div>
            </Modal>

            {/* Bulk AI Modal */}
            <Modal isOpen={showBulkModal} onClose={() => !isBulkGenerating && setShowBulkModal(false)} title="Bulk Product Generator">
                <div className="space-y-4">
                    <div className="bg-indigo-50 p-4 rounded-xl text-sm text-indigo-800 border border-indigo-100">
                        Generate multiple unique products at once based on a theme. Images will be generated automatically.
                    </div>
                    <Input 
                        label="Topic / Category Theme" 
                        placeholder="e.g. Summer Floral Dresses, Gaming Keyboards" 
                        value={bulkTopic} 
                        onChange={e => setBulkTopic(e.target.value)} 
                    />
                    <Input 
                        label="Quantity (Max 5)" 
                        type="number" 
                        min={1} 
                        max={5} 
                        value={bulkCount} 
                        onChange={e => setBulkCount(Number(e.target.value))} 
                    />
                    {isBulkGenerating && (
                        <div className="flex items-center justify-center gap-2 text-sm text-blue-600 font-medium py-2">
                            <Loader2 className="animate-spin" size={16}/> {bulkProgress}
                        </div>
                    )}
                    <Button className="w-full bg-indigo-600 hover:bg-indigo-700 text-white" onClick={handleBulkGenerate} isLoading={isBulkGenerating}>
                        <Layers size={18} className="mr-2" /> Start Bulk Generation
                    </Button>
                </div>
            </Modal>

            {/* Edit/Add Modal */}
            <Modal isOpen={!!editing} onClose={() => setEditing(null)} title={editing?.id ? 'Edit Product' : 'Add Product'}>
                <div className="space-y-4">
                    <Input label="Product Name" value={editing?.name || ''} onChange={e => setEditing({ ...editing, name: e.target.value })} />
                    <div className="flex gap-2">
                         <Input label="Price" type="number" value={editing?.price || ''} onChange={e => setEditing({ ...editing, price: Number(e.target.value) })} />
                         <Input label="MRP" type="number" value={editing?.mrp || ''} onChange={e => setEditing({ ...editing, mrp: Number(e.target.value) })} />
                    </div>
                    <div>
                        <label className="text-xs font-medium text-gray-500 ml-1">Category</label>
                        <select 
                            className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm"
                            value={editing?.categoryId || ''}
                            onChange={e => setEditing({...editing, categoryId: e.target.value})}
                        >
                            <option value="">Select Category</option>
                            {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                        </select>
                    </div>
                    <Input label="Images (Comma separated URLs)" value={editing?.images?.join(',') || ''} onChange={e => setEditing({ ...editing, images: e.target.value.split(',') })} />
                    <Input label="Sizes (Comma separated, e.g., S,M,L)" value={editing?.sizes?.join(',') || ''} onChange={e => setEditing({ ...editing, sizes: e.target.value.split(',').filter(s=>s.trim()) })} />
                    
                    <div className="flex flex-col gap-1">
                        <label className="text-xs font-medium text-gray-500 ml-1">Description</label>
                        <textarea className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" rows={3} value={editing?.description || ''} onChange={e => setEditing({ ...editing, description: e.target.value })}></textarea>
                    </div>
                    
                    <div className="flex gap-4">
                        <label className="flex items-center gap-2">
                            <input type="checkbox" checked={editing?.isTrusted || false} onChange={e => setEditing({...editing, isTrusted: e.target.checked})} />
                            <span className="text-sm">Trusted Badge</span>
                        </label>
                        <label className="flex items-center gap-2">
                            <input type="checkbox" checked={editing?.freeDelivery || false} onChange={e => setEditing({...editing, freeDelivery: e.target.checked})} />
                            <span className="text-sm">Free Delivery</span>
                        </label>
                    </div>

                    <div className="bg-gray-50 p-3 rounded-xl border border-gray-100">
                        <h4 className="font-bold text-sm mb-2">Fake Reviews Management</h4>
                        <div className="space-y-2 mb-2 max-h-32 overflow-y-auto">
                            {editing?.reviews?.map((r, i) => (
                                <div key={i} className="text-xs flex justify-between bg-white p-2 rounded border border-gray-100">
                                    <span>{r.userName}: {r.text.substring(0, 20)}...</span>
                                    <button onClick={() => setEditing(prev => ({...prev, reviews: prev?.reviews?.filter((_, idx) => idx !== i)}))} className="text-red-500">x</button>
                                </div>
                            ))}
                        </div>
                        <div className="grid grid-cols-2 gap-2 mb-2">
                             <Input placeholder="User Name" value={newReview.userName || ''} onChange={e => setNewReview({...newReview, userName: e.target.value})} className="text-xs py-2" />
                             <Input placeholder="Rating (1-5)" type="number" value={newReview.rating || ''} onChange={e => setNewReview({...newReview, rating: Number(e.target.value)})} className="text-xs py-2" />
                        </div>
                        <Input placeholder="Review Text" value={newReview.text || ''} onChange={e => setNewReview({...newReview, text: e.target.value})} className="text-xs py-2 mb-2" />
                        <Input placeholder="User Image URL (Optional)" value={newReview.userImage || ''} onChange={e => setNewReview({...newReview, userImage: e.target.value})} className="text-xs py-2 mb-2" />
                        <Button variant="secondary" size="sm" onClick={addFakeReview} className="w-full">Add Fake Review</Button>
                    </div>

                    <Button className="w-full" onClick={handleSave}>Save Product</Button>
                </div>
            </Modal>
            
            <ConfirmModal 
                isOpen={!!deleteId} 
                onClose={() => setDeleteId(null)} 
                onConfirm={confirmDelete}
                title="Delete Product"
                message="Are you sure you want to delete this product? This cannot be undone."
                isLoading={isDeleting}
            />
        </div>
    );
};

const CategoriesScreen = () => {
    const { addToast } = useApp();
    const [categories, setCategories] = useState<Category[]>([]);
    const [editing, setEditing] = useState<Partial<Category> | null>(null);
    const [deleteId, setDeleteId] = useState<string|null>(null);
    const [isDeleting, setIsDeleting] = useState(false);

    useEffect(() => {
        const fetch = async () => {
            const snap = await getDocs(collection(db, 'categories'));
            setCategories(snap.docs.map(d => ({ id: d.id, ...d.data() } as Category)));
        };
        fetch();
    }, []);

    const handleSave = async () => {
        if (!editing || !editing.name) return;
        try {
            if (editing.id) {
                await updateDoc(doc(db, 'categories', editing.id), editing);
                setCategories(prev => prev.map(c => c.id === editing.id ? { ...c, ...editing } as Category : c));
            } else {
                const res = await addDoc(collection(db, 'categories'), editing);
                setCategories(prev => [...prev, { id: res.id, ...editing } as Category]);
            }
            setEditing(null);
            addToast('Category saved', 'success');
        } catch (e) {
            addToast('Error saving', 'error');
        }
    };

    const confirmDelete = async () => {
        if (!deleteId) return;
        setIsDeleting(true);
        try {
            await deleteDoc(doc(db, 'categories', deleteId));
            setCategories(prev => prev.filter(c => c.id !== deleteId));
            addToast('Category deleted', 'success');
        } catch(e) {
            addToast('Error deleting', 'error');
        } finally {
            setIsDeleting(false);
            setDeleteId(null);
        }
    };

    return (
        <div>
             <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">Categories</h2>
                <Button onClick={() => setEditing({})}>
                    <Plus size={18} className="mr-2" /> Add Category
                </Button>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {categories.map(c => (
                    <div key={c.id} className="bg-white p-4 rounded-xl shadow-sm text-center border border-gray-100 relative group">
                        <img src={c.image} className="w-16 h-16 mx-auto rounded-full object-cover mb-2 bg-gray-50" />
                        <p className="font-bold text-sm">{c.name}</p>
                        <div className="absolute top-2 right-2 hidden group-hover:flex gap-1">
                             <button onClick={()=>setEditing(c)} className="p-1 bg-blue-100 text-blue-600 rounded"><Edit size={12}/></button>
                             <button onClick={()=>setDeleteId(c.id)} className="p-1 bg-red-100 text-red-600 rounded"><Trash size={12}/></button>
                        </div>
                    </div>
                ))}
            </div>

            <Modal isOpen={!!editing} onClose={() => setEditing(null)} title={editing?.id ? 'Edit Category' : 'Add Category'}>
                <div className="space-y-4">
                    <Input label="Category Name" value={editing?.name || ''} onChange={e => setEditing({ ...editing, name: e.target.value })} />
                    <Input label="Image URL" value={editing?.image || ''} onChange={e => setEditing({ ...editing, image: e.target.value })} />
                    <Input label="Sub-Categories (Comma separated)" value={editing?.subCategories?.join(',') || ''} onChange={e => setEditing({ ...editing, subCategories: e.target.value.split(',').filter(x=>x.trim()) })} />
                    <Button className="w-full" onClick={handleSave}>Save</Button>
                </div>
            </Modal>
            
            <ConfirmModal 
                isOpen={!!deleteId} 
                onClose={() => setDeleteId(null)} 
                onConfirm={confirmDelete}
                title="Delete Category"
                message="Are you sure you want to delete this category?"
                isLoading={isDeleting}
            />
        </div>
    );
};

const OrdersScreen = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusNote, setStatusNote] = useState('');
  const { addToast } = useApp();
  
  const [deleteId, setDeleteId] = useState<string|null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
     // Use real-time snapshot to ensure deletion syncs immediately
     const unsub = onSnapshot(query(collection(db, 'orders'), orderBy('createdAt', 'desc')), (snapshot) => {
         setOrders(snapshot.docs.map(d => ({id: d.id, ...d.data()} as Order)));
     });
     return () => unsub();
  }, []);

  const updateStatus = async (status: string) => {
     if(!selectedOrder) return;
     const newTimeline = [...selectedOrder.timeline, { status, date: new Date().toISOString(), note: statusNote || `Status updated to ${status}` }];
     await updateDoc(doc(db, 'orders', selectedOrder.id), { status, timeline: newTimeline });
     setSelectedOrder(null);
     setStatusNote('');
  };

  const confirmDelete = async () => {
      if(!deleteId) return;
      setIsDeleting(true);
      try {
        await deleteDoc(doc(db, 'orders', deleteId));
        if(selectedOrder?.id === deleteId) setSelectedOrder(null);
        addToast("Order deleted", "success");
      } catch(e: any) {
          if(e.code === 'permission-denied') {
              addToast("Permission Denied: Check Firebase Rules", "error");
          } else {
              addToast("Failed to delete order.", "error");
          }
      } finally {
          setIsDeleting(false);
          setDeleteId(null);
      }
  }

  const filtered = orders.filter(o => o.id.includes(searchTerm) || o.uid.includes(searchTerm));

  return (
     <div>
        <h2 className="text-2xl font-bold mb-4">Orders</h2>
        <div className="mb-4 bg-white p-4 rounded-xl shadow-sm">
             <Input placeholder="Search Order ID or User UID" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
        </div>
        <div className="space-y-3">
           {filtered.map(order => (
              <div key={order.id} className="bg-white p-4 rounded-xl shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                 <div>
                    <div className="font-bold text-gray-900">{order.id}</div>
                    <div className="text-sm text-gray-500">User: {order.uid}</div>
                    <div className="text-sm font-medium mt-1">Total: ₹{order.finalAmount} ({order.paymentMethod})</div>
                 </div>
                 <div className="flex flex-col items-end gap-2 w-full sm:w-auto">
                    <Badge color={order.status === 'Delivered' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}>{order.status}</Badge>
                    <div className="flex gap-2">
                        <Button variant="secondary" size="sm" onClick={()=>setSelectedOrder(order)} className="w-full sm:w-auto">Manage</Button>
                        <button onClick={() => setDeleteId(order.id)} className="p-2 text-red-600 bg-red-50 hover:bg-red-100 rounded-lg"><Trash size={16}/></button>
                    </div>
                 </div>
              </div>
           ))}
        </div>
        <Modal isOpen={!!selectedOrder} onClose={()=>{setSelectedOrder(null); setStatusNote('');}} title={`Manage Order ${selectedOrder?.id}`}>
           <div className="space-y-4">
              <div className="flex justify-between items-center mb-2">
                 <h4 className="font-bold">Update Status</h4>
              </div>
              <div>
                 <Input 
                    placeholder="Enter status note (e.g., Arrived at sorting center)" 
                    value={statusNote} 
                    onChange={e => setStatusNote(e.target.value)} 
                    className="mb-3"
                 />
                 <div className="flex flex-wrap gap-2">
                    {['Processing', 'Shipped', 'Delivered', 'Cancelled'].map(s => (
                       <Button key={s} variant="secondary" onClick={()=>updateStatus(s)}>{s}</Button>
                    ))}
                 </div>
              </div>
              <div className="max-h-40 overflow-y-auto bg-gray-50 p-2 rounded">
                 {selectedOrder?.timeline.map((t, i) => (
                    <div key={i} className="text-xs mb-2">
                       <span className="font-bold">{t.status}</span> - {new Date(t.date).toLocaleString()}
                       {t.note && <div className="text-gray-500 ml-2 italic">- {t.note}</div>}
                    </div>
                 ))}
              </div>
           </div>
        </Modal>
        
        <ConfirmModal 
            isOpen={!!deleteId} 
            onClose={() => setDeleteId(null)} 
            onConfirm={confirmDelete}
            title="Delete Order"
            message="Are you sure you want to delete this order record?"
            isLoading={isDeleting}
        />
     </div>
  );
};

const SettingsScreen = () => {
   const { settings, fetchSettings, addToast } = useApp();
   const [localSettings, setLocalSettings] = useState<any>(settings || {});
   const [activeTab, setActiveTab] = useState<'general' | 'policies' | 'coupons'>('general');
   const [coupons, setCoupons] = useState<Coupon[]>([]);
   const [newCoupon, setNewCoupon] = useState<Partial<Coupon>>({ discountType: 'PERCENTAGE', active: true });
   
   const [deleteId, setDeleteId] = useState<string|null>(null);
   const [isDeleting, setIsDeleting] = useState(false);

   useEffect(() => {
       // Fetch coupons
       const fetchCoupons = async () => {
           const snap = await getDocs(collection(db, 'coupons'));
           setCoupons(snap.docs.map(d => ({ id: d.id, ...d.data() } as Coupon)));
       };
       fetchCoupons();
   }, []);

   const handleSaveSettings = async () => {
      await setDoc(doc(db, 'settings', 'general'), localSettings);
      await fetchSettings();
      addToast('Settings saved', 'success');
   };

   const handleAddCoupon = async () => {
       if(!newCoupon.code || !newCoupon.value) return addToast('Enter code and value', 'error');
       const couponData = { ...newCoupon, code: newCoupon.code.toUpperCase() };
       const res = await addDoc(collection(db, 'coupons'), couponData);
       setCoupons(prev => [...prev, { id: res.id, ...couponData } as Coupon]);
       setNewCoupon({ discountType: 'PERCENTAGE', active: true });
       addToast('Coupon added', 'success');
   };

   const confirmDelete = async () => {
       if(!deleteId) return;
       setIsDeleting(true);
       try {
        await deleteDoc(doc(db, 'coupons', deleteId));
        setCoupons(prev => prev.filter(c => c.id !== deleteId));
        addToast('Coupon deleted', 'success');
       } catch (error) {
           addToast('Error deleting', 'error');
       } finally {
           setIsDeleting(false);
           setDeleteId(null);
       }
   };

   return (
      <div className="max-w-4xl mx-auto">
         <h2 className="text-2xl font-bold mb-6">Store Settings</h2>
         
         <div className="flex gap-2 mb-6 border-b border-gray-200">
             <button onClick={()=>setActiveTab('general')} className={`px-4 py-2 font-medium text-sm border-b-2 transition-colors ${activeTab === 'general' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>General</button>
             <button onClick={()=>setActiveTab('policies')} className={`px-4 py-2 font-medium text-sm border-b-2 transition-colors ${activeTab === 'policies' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>Policies</button>
             <button onClick={()=>setActiveTab('coupons')} className={`px-4 py-2 font-medium text-sm border-b-2 transition-colors ${activeTab === 'coupons' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>Coupons</button>
         </div>

         <div className="bg-white p-6 rounded-2xl shadow-sm">
            {activeTab === 'general' && (
                <div className="space-y-4 max-w-xl">
                    <Input label="Site Name" value={localSettings.siteName || ''} onChange={e=>setLocalSettings({...localSettings, siteName: e.target.value})} />
                    <Input label="Logo URL" value={localSettings.logoUrl || ''} onChange={e=>setLocalSettings({...localSettings, logoUrl: e.target.value})} />
                    <Input label="Admin UPI ID" value={localSettings.adminUpiId || ''} onChange={e=>setLocalSettings({...localSettings, adminUpiId: e.target.value})} />
                    <label className="flex items-center gap-3 p-3 border rounded-xl bg-gray-50">
                        <input type="checkbox" checked={localSettings.codEnabled || false} onChange={e=>setLocalSettings({...localSettings, codEnabled: e.target.checked})} className="w-5 h-5 text-blue-600 rounded" />
                        <span className="font-medium text-gray-700">Enable Cash on Delivery (COD)</span>
                    </label>
                    <Button onClick={handleSaveSettings}>Save General Settings</Button>
                </div>
            )}

            {activeTab === 'policies' && (
                <div className="space-y-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Privacy Policy</label>
                        <textarea className="w-full h-32 p-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-sm" value={localSettings.privacyPolicy || ''} onChange={e=>setLocalSettings({...localSettings, privacyPolicy: e.target.value})}></textarea>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Terms & Conditions</label>
                        <textarea className="w-full h-32 p-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-sm" value={localSettings.termsConditions || ''} onChange={e=>setLocalSettings({...localSettings, termsConditions: e.target.value})}></textarea>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Refund Policy</label>
                        <textarea className="w-full h-32 p-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-sm" value={localSettings.refundPolicy || ''} onChange={e=>setLocalSettings({...localSettings, refundPolicy: e.target.value})}></textarea>
                    </div>
                    <Button onClick={handleSaveSettings}>Save Policies</Button>
                </div>
            )}

            {activeTab === 'coupons' && (
                <div>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-3 mb-6 bg-gray-50 p-4 rounded-xl">
                        <Input placeholder="Coupon Code (e.g. SAVE20)" value={newCoupon.code || ''} onChange={e=>setNewCoupon({...newCoupon, code: e.target.value})} className="uppercase" />
                        <select className="bg-white border border-gray-200 rounded-xl px-4 py-3 text-sm" value={newCoupon.discountType} onChange={e=>setNewCoupon({...newCoupon, discountType: e.target.value as any})}>
                            <option value="PERCENTAGE">Percentage (%)</option>
                            <option value="FLAT">Flat Amount (₹)</option>
                        </select>
                        <Input placeholder="Value" type="number" value={newCoupon.value || ''} onChange={e=>setNewCoupon({...newCoupon, value: Number(e.target.value)})} />
                        <Button onClick={handleAddCoupon}>Add Coupon</Button>
                    </div>

                    <div className="space-y-3">
                        {coupons.map(coupon => (
                            <div key={coupon.id} className="flex justify-between items-center p-4 border border-gray-100 rounded-xl hover:bg-gray-50 transition-colors">
                                <div className="flex items-center gap-4">
                                    <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center text-green-600">
                                        <Ticket size={20} />
                                    </div>
                                    <div>
                                        <h4 className="font-bold text-gray-900">{coupon.code}</h4>
                                        <p className="text-xs text-gray-500">{coupon.discountType === 'PERCENTAGE' ? `${coupon.value}% OFF` : `₹${coupon.value} OFF`}</p>
                                    </div>
                                </div>
                                <Button variant="danger" size="sm" onClick={()=>setDeleteId(coupon.id)} className="h-8 px-3">Delete</Button>
                            </div>
                        ))}
                        {coupons.length === 0 && <p className="text-center text-gray-400 py-4">No coupons active.</p>}
                    </div>
                </div>
            )}
         </div>
         
         <ConfirmModal 
            isOpen={!!deleteId} 
            onClose={() => setDeleteId(null)} 
            onConfirm={confirmDelete}
            title="Delete Coupon"
            message="Are you sure you want to delete this coupon?"
            isLoading={isDeleting}
        />
      </div>
   );
};

export const AdminRoutes = () => (
   <AdminLayout>
      <Routes>
         <Route path="/" element={<Dashboard />} />
         <Route path="/users" element={<UsersScreen />} />
         <Route path="/orders" element={<OrdersScreen />} />
         <Route path="/products" element={<ProductsScreen />} />
         <Route path="/categories" element={<CategoriesScreen />} />
         <Route path="/settings" element={<SettingsScreen />} />
      </Routes>
   </AdminLayout>
);