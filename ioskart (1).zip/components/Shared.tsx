import React from 'react';
import { Loader2, X, Check, Info, AlertTriangle } from 'lucide-react';

export const Button: React.FC<React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger', isLoading?: boolean }> = ({ 
  children, variant = 'primary', className = '', isLoading, ...props 
}) => {
  const baseStyle = "active:scale-95 transition-all duration-200 rounded-xl px-4 py-3 font-semibold text-sm flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed select-none";
  const variants = {
    primary: "bg-blue-600 text-white hover:bg-blue-700 shadow-md shadow-blue-200",
    secondary: "bg-gray-100 text-gray-900 hover:bg-gray-200",
    outline: "border-2 border-gray-200 text-gray-700 hover:bg-gray-50",
    ghost: "text-blue-600 hover:bg-blue-50",
    danger: "bg-red-50 text-red-600 hover:bg-red-100"
  };

  return (
    <button className={`${baseStyle} ${variants[variant]} ${className}`} {...props}>
      {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : children}
    </button>
  );
};

export const Input: React.FC<React.InputHTMLAttributes<HTMLInputElement> & { label?: string }> = ({ label, className = '', ...props }) => (
  <div className="flex flex-col gap-1.5 w-full">
    {label && <label className="text-xs font-medium text-gray-500 ml-1">{label}</label>}
    <input 
      className={`w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all ${className}`}
      {...props}
    />
  </div>
);

export const Modal: React.FC<{ isOpen: boolean; onClose: () => void; title: string; children: React.ReactNode }> = ({ isOpen, onClose, title, children }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm transition-opacity" onClick={onClose} />
      <div className="bg-white rounded-[2rem] w-full max-w-md max-h-[90vh] overflow-y-auto shadow-2xl z-10 animate-[scale-in_0.2s_ease-out] relative flex flex-col">
        <div className="sticky top-0 bg-white/80 backdrop-blur-md px-6 py-4 border-b border-gray-100 flex items-center justify-between z-20">
          <h3 className="font-bold text-lg text-gray-900">{title}</h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors"><X className="w-5 h-5 text-gray-500" /></button>
        </div>
        <div className="p-6">
          {children}
        </div>
      </div>
    </div>
  );
};

export const ConfirmModal: React.FC<{ isOpen: boolean; onClose: () => void; onConfirm: () => void; title: string; message: string; isLoading?: boolean }> = ({ isOpen, onClose, onConfirm, title, message, isLoading }) => {
    if (!isOpen) return null;
    return (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/40 backdrop-blur-sm transition-opacity" onClick={isLoading ? undefined : onClose} />
            <div className="bg-white rounded-[2rem] w-full max-w-sm shadow-2xl z-10 animate-[scale-in_0.2s_ease-out] p-6 text-center">
                <div className="w-14 h-14 bg-red-50 text-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <AlertTriangle size={28} />
                </div>
                <h3 className="font-bold text-lg text-gray-900 mb-2">{title}</h3>
                <p className="text-gray-500 text-sm mb-6">{message}</p>
                <div className="flex gap-3">
                    <Button variant="secondary" onClick={onClose} className="flex-1" disabled={isLoading}>Cancel</Button>
                    <Button variant="danger" onClick={onConfirm} className="flex-1 bg-red-600 text-white hover:bg-red-700" isLoading={isLoading}>Delete</Button>
                </div>
            </div>
        </div>
    );
};

export const ToastContainer: React.FC<{ toasts: any[], removeToast: (id: string) => void }> = ({ toasts, removeToast }) => (
  <div className="fixed top-0 left-0 right-0 p-4 z-[100] flex flex-col items-center gap-3 pointer-events-none">
    {toasts.map(toast => (
      <div 
        key={toast.id} 
        onClick={() => removeToast(toast.id)}
        className="pointer-events-auto bg-white/90 backdrop-blur-md border border-gray-200 shadow-xl shadow-gray-200/50 rounded-full px-4 py-3 flex items-center gap-3 min-w-[300px] max-w-md animate-[slide-in-top_0.3s_ease-out] cursor-pointer hover:scale-105 transition-transform"
      >
        <div className={`p-1.5 rounded-full ${toast.type === 'success' ? 'bg-green-100 text-green-600' : toast.type === 'error' ? 'bg-red-100 text-red-600' : 'bg-blue-100 text-blue-600'}`}>
          {toast.type === 'success' ? <Check size={14} strokeWidth={3} /> : toast.type === 'error' ? <X size={14} strokeWidth={3} /> : <Info size={14} strokeWidth={3} />}
        </div>
        <p className="text-sm font-semibold text-gray-800 flex-1">{toast.message}</p>
      </div>
    ))}
  </div>
);

export const Badge: React.FC<{ children: React.ReactNode; color?: string }> = ({ children, color = "bg-blue-100 text-blue-700" }) => (
  <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider ${color}`}>
    {children}
  </span>
);