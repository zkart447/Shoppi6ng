import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider, useApp } from './store';
import { ClientRoutes } from './pages/ClientApp';
import { AdminRoutes } from './pages/AdminPanel';
import { ToastContainer } from './components/Shared';

const AppContent = () => {
  const { profile, toasts, removeToast, isLoading } = useApp();

  if (isLoading) return <div className="h-screen flex items-center justify-center"><div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div></div>;

  return (
    <>
      <ToastContainer toasts={toasts} removeToast={removeToast} />
      <Routes>
        <Route path="/admin/*" element={profile?.isAdmin ? <AdminRoutes /> : <Navigate to="/" />} />
        <Route path="/*" element={<ClientRoutes />} />
      </Routes>
    </>
  );
};

const App = () => (
  <AppProvider>
    <HashRouter>
      <AppContent />
    </HashRouter>
  </AppProvider>
);

export default App;
