import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || 'AIzaSyCAbQYu92R10mkzLl9uyTLRbeTjjPOM4w0' });

export const getChatResponse = async (history: string[], userMessage: string, siteName: string) => {
  try {
    const model = ai.models;
    const response = await model.generateContent({
      model: 'gemini-2.5-flash',
      contents: userMessage, 
      config: {
        systemInstruction: `You are a helpful customer support AI assistant for an e-commerce store named ${siteName}. 
        Be polite, concise, and helpful. 
        You can answer general questions about orders, refunds (usually 3-8 days), and shipping (usually 9 days).`,
      }
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "I'm having trouble connecting right now. Please try again later.";
  }
};

const productSchema = {
    type: Type.OBJECT,
    properties: {
        name: { type: Type.STRING },
        description: { type: Type.STRING },
        price: { type: Type.NUMBER },
        mrp: { type: Type.NUMBER },
        reviews: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    userName: { type: Type.STRING },
                    userImage: { type: Type.STRING, description: "Use https://ui-avatars.com/api/?name=Name" },
                    rating: { type: Type.NUMBER },
                    text: { type: Type.STRING },
                    date: { type: Type.STRING, description: "ISO date string" }
                }
            }
        },
        sizes: { type: Type.ARRAY, items: { type: Type.STRING } }
    }
};

// Helper to compress base64 images to avoid Firestore 1MB limit
const compressBase64Image = (base64Str: string): Promise<string> => {
    return new Promise((resolve) => {
        const img = new Image();
        img.src = base64Str;
        img.onload = () => {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            
            // Resize to max 800x800 to ensure small size
            const maxSize = 800;
            let width = img.width;
            let height = img.height;

            if (width > height) {
                if (width > maxSize) {
                    height *= maxSize / width;
                    width = maxSize;
                }
            } else {
                if (height > maxSize) {
                    width *= maxSize / height;
                    height = maxSize;
                }
            }

            canvas.width = width;
            canvas.height = height;
            
            // Draw on white background (for transparent PNGs conversion)
            if (ctx) {
                ctx.fillStyle = '#FFFFFF';
                ctx.fillRect(0, 0, width, height);
                ctx.drawImage(img, 0, 0, width, height);
            }

            // Compress to JPEG with 0.7 quality
            const compressed = canvas.toDataURL('image/jpeg', 0.7);
            resolve(compressed);
        };
        img.onerror = () => {
            console.warn("Image compression failed, using original");
            resolve(base64Str);
        };
    });
};

export const generateProductMetadata = async (prompt: string, reviewCount: number) => {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Generate product details for: ${prompt}. Generate exactly ${reviewCount} realistic reviews.`,
            config: {
                responseMimeType: "application/json",
                responseSchema: productSchema
            }
        });
        return JSON.parse(response.text || '{}');
    } catch (error) {
        console.error("AI Text Gen Error", error);
        return null;
    }
};

export const generateBulkProductMetadata = async (topic: string, count: number) => {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Generate ${count} distinct and unique product details for the topic: ${topic}. Each product should have 2 realistic reviews.`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: productSchema
                }
            }
        });
        return JSON.parse(response.text || '[]');
    } catch (error) {
        console.error("AI Bulk Gen Error", error);
        return [];
    }
}

export const generateProductImage = async (prompt: string) => {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: {
                parts: [{ text: `A professional, high-quality, white background product photography of ${prompt}` }]
            },
            config: {
                imageConfig: {
                    aspectRatio: "1:1"
                }
            }
        });
        
        for (const part of response.candidates[0].content.parts) {
            if (part.inlineData) {
                const rawBase64 = `data:image/png;base64,${part.inlineData.data}`;
                // Compress before returning to fit Firestore limits
                return await compressBase64Image(rawBase64);
            }
        }
        return null;
    } catch (error) {
        console.error("AI Image Gen Error", error);
        return null;
    }
};