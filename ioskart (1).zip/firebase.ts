import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyCAbQYu92R10mkzLl9uyTLRbeTjjPOM4w0",
  authDomain: "shopping-69567.firebaseapp.com",
  projectId: "shopping-69567",
  storageBucket: "shopping-69567.firebasestorage.app",
  messagingSenderId: "95973589108",
  appId: "1:95973589108:web:346c61bd6d90e9489b5121",
  measurementId: "G-BYVS7VPZ8T"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const googleProvider = new GoogleAuthProvider();
