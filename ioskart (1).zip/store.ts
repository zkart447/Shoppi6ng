import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, onAuthStateChanged, signOut } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db } from './firebase';
import { UserProfile, CartItem, AppSettings, ToastMessage } from './types';

interface AppState {
  user: User | null;
  profile: UserProfile | null;
  cart: CartItem[];
  settings: AppSettings | null;
  isLoading: boolean;
  toasts: ToastMessage[];
  addToCart: (item: Partial<CartItem> & { id: string }) => void;
  removeFromCart: (cartItemId: string) => void;
  clearCart: () => void;
  updateCartQuantity: (cartItemId: string, qty: number) => void;
  addToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  removeToast: (id: string) => void;
  refreshProfile: () => Promise<void>;
  fetchSettings: () => Promise<void>;
}

const AppContext = createContext<AppState | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Toast Logic
  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const addToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = Date.now().toString() + Math.random().toString();
    setToasts(prev => [...prev, { id, message, type }]);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
      removeToast(id);
    }, 3000);
  };

  // Cart Logic
  useEffect(() => {
    const storedCart = localStorage.getItem('ioskart_cart');
    if (storedCart) setCart(JSON.parse(storedCart));
  }, []);

  useEffect(() => {
    localStorage.setItem('ioskart_cart', JSON.stringify(cart));
  }, [cart]);

  const addToCart = (item: any) => {
    // Create a unique ID for the cart item based on Product ID and Selected Size
    const uniqueId = item.selectedSize ? `${item.id}-${item.selectedSize}` : item.id;
    
    setCart(prev => {
      const existing = prev.find(i => i.cartItemId === uniqueId);
      if (existing) {
        addToast('Item quantity updated', 'success');
        return prev.map(i => i.cartItemId === uniqueId ? { ...i, quantity: i.quantity + (item.quantity || 1) } : i);
      }
      addToast('Added to cart', 'success');
      return [...prev, { ...item, cartItemId: uniqueId, quantity: item.quantity || 1 }];
    });
  };

  const removeFromCart = (cartItemId: string) => setCart(prev => prev.filter(i => i.cartItemId !== cartItemId));
  
  const updateCartQuantity = (cartItemId: string, qty: number) => {
    if (qty <= 0) return removeFromCart(cartItemId);
    setCart(prev => prev.map(i => i.cartItemId === cartItemId ? { ...i, quantity: qty } : i));
  };
  const clearCart = () => setCart([]);

  // Auth & Profile Logic
  const fetchProfile = async (uid: string) => {
    try {
      const docRef = doc(db, 'users', uid);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const userData = docSnap.data() as UserProfile;
        
        // CHECK IF BLOCKED
        if (userData.isBlocked) {
            await signOut(auth);
            setProfile(null);
            setUser(null);
            addToast("Your account has been blocked by admin.", "error");
            return;
        }

        // ADMIN OVERRIDE LOGIC
        if (userData.email === 'admin@ioskart.com') {
          userData.isAdmin = true;
        }

        setProfile(userData);
      }
    } catch (error) {
      console.error("Error fetching profile:", error);
    }
  };

  const fetchSettings = async () => {
    try {
      const docRef = doc(db, 'settings', 'general');
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const s = docSnap.data() as AppSettings;
        setSettings(s);
        document.title = s.siteName || 'IosKart Store';
      } else {
        // Default settings
        setSettings({
          siteName: 'IosKart',
          logoUrl: 'https://cdn-icons-png.flaticon.com/512/3081/3081559.png',
          theme: 'ios',
          codEnabled: true,
          adminUpiId: 'merchant@upi',
          privacyPolicy: 'Your privacy is important...',
          termsConditions: 'Terms of service...',
          refundPolicy: '7-day refund policy...'
        });
        document.title = 'IosKart Store';
      }
    } catch (e) {
      console.log("Error settings", e);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        // Only set user if we successfully fetch profile and not blocked
        await fetchProfile(currentUser.uid);
        // Note: fetchProfile handles blocking logic which triggers signOut
        // We set local user state here, but if signOut happens inside fetchProfile, 
        // onAuthStateChanged will fire again with null.
        setUser(currentUser);
      } else {
        setUser(null);
        setProfile(null);
      }
      setIsLoading(false);
    });
    fetchSettings();
    return () => unsubscribe();
  }, []);

  return React.createElement(AppContext.Provider, {
    value: { 
      user, profile, cart, settings, isLoading, toasts, 
      addToCart, removeFromCart, clearCart, updateCartQuantity, 
      addToast, removeToast, refreshProfile: async () => { if(auth.currentUser) await fetchProfile(auth.currentUser.uid) }, fetchSettings 
    }
  }, children);
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error("useApp must be used within AppProvider");
  return context;
};