export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  phoneNumber?: string;
  isAdmin: boolean;
  isBlocked?: boolean; // New field for blocking logic
  addresses: Address[];
  bankDetails?: BankDetails;
  createdAt: number;
}

export interface Address {
  id: string;
  fullName: string;
  street: string;
  landmark?: string;
  city: string; // District
  state: string;
  zipCode: string;
  mobile: string;
}

export interface BankDetails {
  accountHolder: string;
  accountNumber: string;
  ifsc: string;
  upiId: string;
}

export interface Category {
  id: string;
  name: string;
  image: string;
  subCategories?: string[];
}

export interface Product {
  id: string;
  name: string;
  categoryId: string;
  description: string;
  price: number;
  mrp: number;
  images: string[]; // Array of URLs
  rating: number;
  isTrusted: boolean;
  freeDelivery: boolean;
  reviews: Review[];
  stock: number;
  sizes?: string[];
}

export interface Review {
  id: string;
  userName: string;
  userImage: string;
  rating: number;
  text: string;
  images?: string[];
  date: string;
}

export interface CartItem extends Product {
  quantity: number;
  selectedSize?: string;
  cartItemId: string; // unique id (productId + size)
}

export interface Order {
  id: string;
  uid: string;
  items: CartItem[];
  totalAmount: number;
  discount: number;
  finalAmount: number;
  address: Address;
  status: 'Pending' | 'Processing' | 'Shipped' | 'Delivered' | 'Cancelled' | 'Refunded';
  timeline: OrderTimeline[];
  paymentMethod: 'COD' | 'Online';
  createdAt: number;
  couponCode?: string;
  couponDiscount?: number;
}

export interface OrderTimeline {
  status: string;
  date: string;
  note?: string;
}

export interface Coupon {
  id: string;
  code: string;
  discountType: 'PERCENTAGE' | 'FLAT';
  value: number;
  active: boolean;
}

export interface AppSettings {
  siteName: string;
  logoUrl: string;
  theme: 'light' | 'dark' | 'ios'; // Just tracking, UI handles it
  codEnabled: boolean;
  adminUpiId: string;
  privacyPolicy: string;
  termsConditions: string;
  refundPolicy: string;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}